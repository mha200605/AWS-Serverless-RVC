import hashlib
import socket
import tempfile
import unittest
from pathlib import Path

from . import conftest_paths  # noqa: F401
from rvc_common.errors import RvcError
from rvc_common.net import FetchPolicy, SafeFetcher, resolve_public_ips
from .fakes import FakeResponse, FakeTransport, resolver

URL = "https://huggingface.co/alice/voices/resolve/main/a.pth"
BODY = b"PK\x03\x04" + b"x" * 5000


def policy(**kw):
    base = dict(allowed_hosts=("huggingface.co",), redirect_suffixes=("hf.co", "huggingface.co"),
                token_hosts=("huggingface.co",), total_timeout=600, retries=2)
    base.update(kw)
    return FetchPolicy(**base)


def make(routes, **kw):
    t = FakeTransport(routes)
    pol = kw.pop("pol", None) or policy()
    return SafeFetcher(pol, transport=t, resolver=kw.pop("res", resolver()), sleep=lambda s: None, **kw), t


def code_of(fn, *a, **k):
    try:
        fn(*a, **k)
    except RvcError as e:
        return e.code
    return None


class FetchTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.dest = self.tmp / "model.pth"

    def test_success_hash_and_no_partial_file(self):
        f, _ = make({("huggingface.co", "/"): FakeResponse(200, BODY)})
        r = f.fetch(URL, self.dest, max_bytes=10_000)
        self.assertEqual(r.sha256, hashlib.sha256(BODY).hexdigest())
        self.assertEqual(self.dest.read_bytes(), BODY)
        self.assertFalse(self.dest.with_name("model.pth.part").exists())
        self.assertEqual(oct(self.dest.stat().st_mode & 0o777), "0o600")

    def test_connection_is_pinned_to_validated_ip(self):
        f, t = make({("huggingface.co", "/"): FakeResponse(200, BODY)}, res=resolver({"huggingface.co": ["1.2.3.4"]}))
        f.fetch(URL, self.dest, max_bytes=10_000)
        self.assertEqual(t.requests[0]["ip"], "1.2.3.4")

    def test_size_limit_content_length(self):
        f, _ = make({("huggingface.co", "/"): FakeResponse(200, BODY)})
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=100), "FILE_TOO_LARGE")
        self.assertFalse(self.dest.exists())

    def test_size_limit_enforced_while_streaming(self):
        # server lies / omits Content-Length
        f, _ = make({("huggingface.co", "/"): FakeResponse(200, BODY, headers={})})
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=1000), "FILE_TOO_LARGE")
        self.assertEqual(list(self.tmp.iterdir()), [])

    def test_token_only_to_allowed_host_and_not_on_cdn_redirect(self):
        cdn = "https://cas-bridge.xethub.hf.co/blob/abc?sig=1"
        f, t = make({("huggingface.co", "/"): FakeResponse(302, b"", headers={"Location": cdn}),
                     ("cas-bridge.xethub.hf.co", "/"): FakeResponse(200, BODY)})
        f.fetch(URL, self.dest, max_bytes=10_000, token_provider=lambda: "hf_SECRETSECRET")
        self.assertEqual(t.requests[0]["headers"]["Authorization"], "Bearer hf_SECRETSECRET")
        self.assertNotIn("Authorization", t.requests[1]["headers"])

    def test_redirect_to_disallowed_host_blocked(self):
        for loc in ["https://evil.com/x", "https://huggingface.co.evil.com/x", "http://hf.co/x",
                    "https://169.254.169.254/latest/meta-data/", "https://user@hf.co/x", "https://hf.co:8080/x"]:
            f, t = make({("huggingface.co", "/"): FakeResponse(302, b"", headers={"Location": loc})})
            self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000), "DOWNLOAD_BLOCKED", loc)
            self.assertEqual(len(t.requests), 1)

    def test_redirect_to_private_ip_via_dns_blocked(self):
        f, t = make({("huggingface.co", "/"): FakeResponse(302, b"", headers={"Location": "https://cdn.hf.co/x"})},
                    res=resolver({"cdn.hf.co": ["10.0.0.7"]}))
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000), "DOWNLOAD_BLOCKED")
        self.assertEqual(len(t.requests), 1)

    def test_first_hop_private_ip_blocked(self):
        f, t = make({}, res=resolver({"huggingface.co": ["127.0.0.1"]}))
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000), "DOWNLOAD_BLOCKED")
        self.assertEqual(t.requests, [])

    def test_first_hop_must_be_allowed_host_even_if_suffix_matches(self):
        f, _ = make({})
        self.assertEqual(code_of(f.fetch, "https://cdn.hf.co/x.pth", self.dest, max_bytes=10), "DOWNLOAD_BLOCKED")

    def test_redirect_loop(self):
        f, _ = make({("huggingface.co", "/"): FakeResponse(302, b"", headers={"Location": URL})})
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000), "DOWNLOAD_FAILED")

    def test_http_status_mapping(self):
        for status, code in [(401, "MODEL_AUTH_FAILED"), (403, "MODEL_AUTH_FAILED"), (404, "DOWNLOAD_NOT_FOUND"),
                             (418, "DOWNLOAD_FAILED")]:
            f, _ = make({("huggingface.co", "/"): FakeResponse(status, b"")})
            self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000), code)

    def test_retry_on_503_then_success(self):
        f, t = make({("huggingface.co", "/"): [FakeResponse(503, b""), FakeResponse(200, BODY)]})
        f.fetch(URL, self.dest, max_bytes=10_000)
        self.assertEqual(len(t.requests), 2)

    def test_gives_up_after_retries(self):
        f, t = make({("huggingface.co", "/"): FakeResponse(503, b"")})
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000), "DOWNLOAD_UNAVAILABLE")
        self.assertEqual(len(t.requests), 3)

    def test_connect_timeout_mapped(self):
        f, _ = make({("huggingface.co", "/"): socket.timeout("boom")})
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000), "DOWNLOAD_TIMEOUT")

    def test_stalled_read_mapped_and_cleaned(self):
        f, _ = make({("huggingface.co", "/"): lambda: FakeResponse(200, BODY, fail_after=128)})
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000), "DOWNLOAD_TIMEOUT")
        self.assertEqual(list(self.tmp.iterdir()), [])

    def test_overall_deadline(self):
        ticks = iter(range(0, 10_000, 100))
        t = FakeTransport({("huggingface.co", "/"): FakeResponse(200, BODY)})
        f = SafeFetcher(policy(total_timeout=250), transport=t, resolver=resolver(), clock=lambda: next(ticks),
                        sleep=lambda s: None)
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000), "DOWNLOAD_TIMEOUT")

    def test_truncated_download_detected(self):
        f, _ = make({("huggingface.co", "/"): FakeResponse(200, BODY[:100], headers={"Content-Length": str(len(BODY))})})
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000), "DOWNLOAD_UNAVAILABLE" if False else "DOWNLOAD_FAILED")

    def test_checksum_mismatch(self):
        f, _ = make({("huggingface.co", "/"): FakeResponse(200, BODY)})
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000, expected_sha256="0" * 64), "CHECKSUM_MISMATCH")
        self.assertFalse(self.dest.exists())

    def test_head_validator(self):
        def reject(head):
            raise RvcError("INVALID_MODEL_FILE", "nope")
        f, _ = make({("huggingface.co", "/"): FakeResponse(200, BODY)})
        self.assertEqual(code_of(f.fetch, URL, self.dest, max_bytes=10_000, head_validator=reject), "INVALID_MODEL_FILE")
        self.assertFalse(self.dest.exists())

    def test_errors_never_contain_token(self):
        token = "hf_SUPERSECRETTOKEN123"
        for status in (401, 404, 503):
            f, _ = make({("huggingface.co", "/"): FakeResponse(status, b"")})
            try:
                f.fetch(URL, self.dest, max_bytes=10, token_provider=lambda: token)
            except RvcError as e:
                self.assertNotIn(token, e.message)
                self.assertNotIn(token, repr(e))


class ResolverTests(unittest.TestCase):
    def fake_gai(self, ips):
        return lambda host, port, type=None: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, port)) for ip in ips]

    def test_blocks_private_ranges(self):
        for ip in ["10.1.2.3", "172.16.0.1", "192.168.1.1", "127.0.0.1", "169.254.169.254", "0.0.0.0", "100.64.0.1"]:
            self.assertEqual(code_of(resolve_public_ips, "x.example", self.fake_gai([ip])), "DOWNLOAD_BLOCKED", ip)

    def test_blocks_if_any_address_private(self):
        self.assertEqual(code_of(resolve_public_ips, "x.example", self.fake_gai(["93.184.216.34", "10.0.0.1"])),
                         "DOWNLOAD_BLOCKED")

    def test_allows_public(self):
        self.assertEqual(resolve_public_ips("x.example", self.fake_gai(["93.184.216.34"])), ["93.184.216.34"])

    def test_resolution_failure_is_retryable_error(self):
        def boom(*a, **k):
            raise socket.gaierror("no")
        self.assertEqual(code_of(resolve_public_ips, "x.example", boom), "DOWNLOAD_FAILED")


if __name__ == "__main__":
    unittest.main()
