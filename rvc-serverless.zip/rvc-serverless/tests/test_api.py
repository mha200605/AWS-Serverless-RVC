import json
import unittest
from datetime import datetime, timezone

from . import conftest_paths  # noqa: F401
from api.handler import Deps, lambda_handler
from rvc_common import keys
from rvc_common.settings import Settings
from .fakes import REPO, SHA, FakeBatch, FakeS3

JOB = "d" * 32
S = Settings(bucket="b", allowed_repos=(REPO,), job_queue="q", job_definition="jd", max_input_bytes=5 * 1024 * 1024)
BODY = {"model": {"repo_id": REPO, "pth": "v/a.pth", "index": "v/a.index", "revision": SHA}, "options": {"pitch": 1}}


def ev(route, body=None, job_id=None, raw=None):
    e = {"routeKey": route, "pathParameters": {"jobId": job_id} if job_id else None}
    if raw is not None:
        e["body"] = raw
    elif body is not None:
        e["body"] = json.dumps(body)
    return e


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.s3, self.batch = FakeS3(), FakeBatch()
        self.deps = Deps(self.s3, self.batch, clock=lambda: datetime.now(timezone.utc).timestamp())

    def call(self, e, settings=S):
        r = lambda_handler(e, None, self.deps, settings)
        return r["statusCode"], json.loads(r["body"]), r

    def create(self):
        code, body, _ = self.call(ev("POST /jobs", BODY))
        self.assertEqual(code, 202)
        return body

    # --- create -------------------------------------------------------------------
    def test_create_returns_job_id_and_size_limited_upload(self):
        body = self.create()
        self.assertRegex(body["jobId"], r"^[0-9a-f]{32}$")
        self.assertEqual(body["status"], "AWAITING_UPLOAD")
        post = self.s3.presigned_posts[0]
        self.assertEqual(post["Key"], keys.input_key(body["jobId"]))
        self.assertIn(["content-length-range", 1, S.max_input_bytes], post["Conditions"])
        self.assertEqual(post["ExpiresIn"], 900)
        self.assertEqual(self.batch.submitted, [])                          # nothing billable yet

    def test_stored_request_is_normalised_and_has_no_secrets(self):
        body = self.create()
        stored = json.loads(self.s3.store[keys.job_key(body["jobId"])])
        self.assertEqual(stored["request"]["model"]["repo_id"], REPO)
        self.assertNotIn("token", json.dumps(stored).lower())

    def test_create_with_url_model(self):
        url = f"https://huggingface.co/{REPO}/resolve/{SHA}/v/a.pth"
        code, body, _ = self.call(ev("POST /jobs", {"model": {"url": url}}))
        self.assertEqual(code, 202)

    def test_rejections(self):
        cases = [
            ({"model": {"repo_id": "evil/x", "pth": "a.pth"}}, 403, "MODEL_NOT_ALLOWED"),
            ({"model": {"repo_id": REPO, "pth": "../a.pth"}}, 400, "INVALID_FILE"),
            ({"model": {"url": "https://169.254.169.254/x"}}, 400, "URL_NOT_ALLOWED"),
            ({"model": {"repo_id": REPO, "pth": "a.pth"}, "options": {"pitch": 500}}, 400, "INVALID_OPTIONS"),
            ({"model": {"repo_id": REPO, "pth": "a.pth"}, "input_url": "https://x.com/a.wav"}, 400, "INPUT_URL_DISABLED"),
            ({}, 400, "INVALID_MODEL"),
            ([], 400, "INVALID_REQUEST"),
        ]
        for body, status, code in cases:
            s, b, _ = self.call(ev("POST /jobs", body))
            self.assertEqual((s, b["error"]["code"]), (status, code), body)
        self.assertEqual(self.s3.store, {})                                 # nothing written on rejected input

    def test_bad_json_and_oversized_body(self):
        self.assertEqual(self.call(ev("POST /jobs", raw="{nope"))[1]["error"]["code"], "INVALID_JSON")
        s, b, _ = self.call(ev("POST /jobs", raw=json.dumps({"x": "a" * 20000})))
        self.assertEqual((s, b["error"]["code"]), (413, "BODY_TOO_LARGE"))

    def test_input_url_queues_immediately_when_enabled(self):
        s = Settings(bucket="b", allowed_repos=(REPO,), job_queue="q", job_definition="jd",
                     allowed_input_hosts=("files.example.com",))
        code, body, _ = self.call(ev("POST /jobs", {**BODY, "input_url": "https://files.example.com/a.wav"}), s)
        self.assertEqual((code, body["status"]), (202, "QUEUED"))
        self.assertEqual(len(self.batch.submitted), 1)

    # --- start --------------------------------------------------------------------
    def test_start_requires_upload(self):
        job = self.create()["jobId"]
        s, b, _ = self.call(ev("POST /jobs/{jobId}/start", job_id=job))
        self.assertEqual((s, b["error"]["code"]), (409, "UPLOAD_MISSING"))
        self.assertEqual(self.batch.submitted, [])

    def test_start_submits_batch_job_once(self):
        job = self.create()["jobId"]
        self.s3.put(keys.input_key(job), b"audio")
        s, b, _ = self.call(ev("POST /jobs/{jobId}/start", job_id=job))
        self.assertEqual((s, b["status"]), (202, "QUEUED"))
        sub = self.batch.submitted[0]
        self.assertEqual((sub["jobQueue"], sub["jobDefinition"]), ("q", "jd"))
        self.assertEqual(sub["containerOverrides"]["environment"], [{"name": "JOB_ID", "value": job}])
        self.call(ev("POST /jobs/{jobId}/start", job_id=job))             # idempotent
        self.assertEqual(len(self.batch.submitted), 1)

    def test_start_rejects_oversized_or_empty_upload(self):
        job = self.create()["jobId"]
        self.s3.put(keys.input_key(job), b"x" * (S.max_input_bytes + 1))
        self.assertEqual(self.call(ev("POST /jobs/{jobId}/start", job_id=job))[1]["error"]["code"], "UPLOAD_INVALID")

    def test_unknown_job(self):
        for route in ("POST /jobs/{jobId}/start", "GET /jobs/{jobId}"):
            s, b, _ = self.call(ev(route, job_id=JOB))
            self.assertEqual((s, b["error"]["code"]), (404, "JOB_NOT_FOUND"))

    def test_malformed_job_id(self):
        s, b, _ = self.call(ev("GET /jobs/{jobId}", job_id="../../etc/passwd"))
        self.assertEqual((s, b["error"]["code"]), (400, "INVALID_JOB_ID"))

    # --- status / result ----------------------------------------------------------
    def started(self):
        job = self.create()["jobId"]
        self.s3.put(keys.input_key(job), b"audio")
        self.call(ev("POST /jobs/{jobId}/start", job_id=job))
        return job

    def status(self, job):
        return self.call(ev("GET /jobs/{jobId}", job_id=job))[1]

    def test_status_before_start(self):
        job = self.create()["jobId"]
        self.assertEqual(self.status(job)["status"], "AWAITING_UPLOAD")

    def test_status_queued_running_success_with_signed_download(self):
        job = self.started()
        for batch_status in ("SUBMITTED", "RUNNABLE", "STARTING"):
            self.batch.status = batch_status
            self.assertEqual(self.status(job)["status"], "QUEUED")
        self.batch.status = "RUNNING"
        self.s3.put(keys.status_key(job), {"state": "RUNNING", "stage": "CONVERTING"})
        out = self.status(job)
        self.assertEqual((out["status"], out["stage"]), ("RUNNING", "CONVERTING"))
        self.assertNotIn("result", out)
        self.batch.status = "SUCCEEDED"
        self.s3.put(keys.status_key(job), {"state": "SUCCEEDED", "result": {"sizeBytes": 10, "durationSeconds": 2.5},
                                           "timings": {"totalSeconds": 3}})
        out = self.status(job)
        self.assertEqual(out["status"], "SUCCEEDED")
        self.assertIn("X-Amz-Signature", out["result"]["url"])
        op, params, expires = self.s3.presigned_urls[-1]
        self.assertEqual((params["Key"], expires), (keys.output_key(job), S.result_url_expiry_seconds))
        self.assertIn("attachment", params["ResponseContentDisposition"])

    def test_no_download_url_until_success(self):
        job = self.started()
        self.batch.status = "RUNNING"
        self.s3.put(keys.status_key(job), {"state": "RUNNING", "stage": "UPLOADING"})
        self.assertNotIn("result", self.status(job))
        self.assertEqual(self.s3.presigned_urls, [])

    def test_worker_reported_failure(self):
        job = self.started()
        self.batch.status = "FAILED"
        self.s3.put(keys.status_key(job), {"state": "FAILED", "error": {"code": "OUTPUT_SILENT", "message": "silent"}})
        out = self.status(job)
        self.assertEqual((out["status"], out["error"]["code"]), ("FAILED", "OUTPUT_SILENT"))

    def test_batch_failure_without_status_file_is_sanitised(self):
        job = self.started()
        self.batch.status, self.batch.reason = "FAILED", "Job attempt duration exceeded timeout of 900 seconds"
        out = self.status(job)
        self.assertEqual(out["error"]["code"], "JOB_TIMEOUT")
        self.batch.reason = "Essential container in task exited; arn:aws:ecs:...:secret-internal-detail"
        out = self.status(job)
        self.assertEqual(out["error"]["code"], "WORKER_FAILED")
        self.assertNotIn("secret-internal-detail", json.dumps(out))

    def test_batch_succeeded_but_no_status(self):
        job = self.started()
        self.batch.status = "SUCCEEDED"
        self.assertEqual(self.status(job)["error"]["code"], "WORKER_NO_RESULT")

    def test_long_runnable_hint_mentions_quota(self):
        job = self.started()
        self.batch.status = "RUNNABLE"
        stored = json.loads(self.s3.store[keys.job_key(job)])
        stored["queuedAt"] = "2020-01-01T00:00:00+00:00"
        self.s3.put(keys.job_key(job), stored)
        self.assertIn("quota", self.status(job)["hint"])

    def test_responses_have_no_cache_and_leak_nothing(self):
        job = self.started()
        _, body, raw = self.call(ev("GET /jobs/{jobId}", job_id=job))
        self.assertEqual(raw["headers"]["Cache-Control"], "no-store")
        text = raw["body"].lower()
        for needle in ("secret", "token", "arn:aws", "bearer"):
            self.assertNotIn(needle, text)

    def test_unknown_route_and_internal_error(self):
        self.assertEqual(self.call(ev("DELETE /jobs"))[0], 404)

        class Broken(FakeS3):
            def put_object(self, **kw):
                raise RuntimeError("kaboom /internal/path")
        self.deps = Deps(Broken(), self.batch)
        s, b, raw = self.call(ev("POST /jobs", BODY))
        self.assertEqual((s, b["error"]["code"]), (500, "INTERNAL_ERROR"))
        self.assertNotIn("kaboom", raw["body"])


if __name__ == "__main__":
    unittest.main()
