"""In-memory fakes. No network, no AWS SDK, no Hugging Face, no real model files."""
import io
import json
import socket
from pathlib import Path

from . import conftest_paths  # noqa: F401

PTH_BYTES = b"PK\x03\x04" + b"fake-pth-weights" * 100
INDEX_BYTES = b"IwFl" + b"fake-faiss-index" * 100
REPO = "alice/voices"
SHA = "a" * 40
PUBLIC_IP = "93.184.216.34"


class FakeClientError(Exception):
    def __init__(self, code):
        super().__init__(code)
        self.response = {"Error": {"Code": code}}


class FakeS3:
    def __init__(self):
        self.store = {}
        self.deleted = []
        self.presigned_posts = []
        self.presigned_urls = []
        self.upload_args = []

    def put(self, key, data):
        self.store[key] = data if isinstance(data, bytes) else json.dumps(data).encode()

    def put_object(self, Bucket, Key, Body, **kw):
        self.store[Key] = Body if isinstance(Body, bytes) else Body.encode()

    def get_object(self, Bucket, Key):
        if Key not in self.store:
            raise FakeClientError("NoSuchKey")
        return {"Body": io.BytesIO(self.store[Key])}

    def head_object(self, Bucket, Key):
        if Key not in self.store:
            raise FakeClientError("404")
        return {"ContentLength": len(self.store[Key])}

    def download_file(self, Bucket, Key, Filename):
        if Key not in self.store:
            raise FakeClientError("404")
        Path(Filename).write_bytes(self.store[Key])

    def upload_file(self, Filename, Bucket, Key, ExtraArgs=None):
        self.store[Key] = Path(Filename).read_bytes()
        self.upload_args.append((Key, ExtraArgs))

    def delete_object(self, Bucket, Key):
        self.deleted.append(Key)
        self.store.pop(Key, None)

    def generate_presigned_post(self, Bucket, Key, Conditions=None, ExpiresIn=3600, **kw):
        self.presigned_posts.append({"Key": Key, "Conditions": Conditions, "ExpiresIn": ExpiresIn})
        return {"url": f"https://{Bucket}.s3.amazonaws.com/", "fields": {"key": Key, "policy": "p", "x-amz-signature": "s"}}

    def generate_presigned_url(self, op, Params, ExpiresIn):
        self.presigned_urls.append((op, Params, ExpiresIn))
        return f"https://{Params['Bucket']}.s3.amazonaws.com/{Params['Key']}?X-Amz-Signature=abc"


class FakeBatch:
    def __init__(self, status="SUBMITTED", reason=""):
        self.submitted = []
        self.status, self.reason = status, reason

    def submit_job(self, **kw):
        self.submitted.append(kw)
        return {"jobId": "batch-123", "jobName": kw["jobName"]}

    def describe_jobs(self, jobs):
        return {"jobs": [{"jobId": jobs[0], "status": self.status, "statusReason": self.reason}]}


class FakeSecrets:
    def __init__(self, value):
        self.value, self.calls = value, 0

    def get_secret_value(self, SecretId):
        self.calls += 1
        return {"SecretString": self.value}


class FakeResponse:
    def __init__(self, status=200, body=b"", headers=None, chunk=64, fail_after=None):
        self.status, self._body, self._pos, self.chunk = status, body, 0, chunk
        self.headers = {k.lower(): v for k, v in (headers or {}).items()}
        if status == 200 and "content-length" not in self.headers and headers is None:
            self.headers["content-length"] = str(len(body))
        self.closed, self.fail_after = False, fail_after

    def getheader(self, name, default=None):
        return self.headers.get(name.lower(), default)

    def read(self, n):
        if self.fail_after is not None and self._pos >= self.fail_after:
            raise socket.timeout("slow")
        data = self._body[self._pos:self._pos + min(n, self.chunk)]
        self._pos += len(data)
        return data

    def close(self):
        self.closed = True


class FakeTransport:
    """Scripted responses keyed by (host, path-prefix); records every request."""

    def __init__(self, routes):
        self.routes, self.requests = routes, []

    def request(self, host, ip, port, target, headers, timeout):
        self.requests.append({"host": host, "ip": ip, "target": target, "headers": dict(headers)})
        for (h, prefix), value in self.routes.items():
            if h == host and target.startswith(prefix):
                if isinstance(value, list):
                    value = value.pop(0) if len(value) > 1 else value[0]
                if isinstance(value, Exception):
                    raise value
                return value() if callable(value) else value
        return FakeResponse(404, b"")


def resolver(mapping=None):
    mapping = mapping or {}

    def _resolve(host):
        ips = mapping.get(host, [PUBLIC_IP])
        import ipaddress
        for ip in ips:
            if not ipaddress.ip_address(ip).is_global:
                from rvc_common.errors import RvcError
                raise RvcError("DOWNLOAD_BLOCKED", "Download target is not permitted.")
        return ips
    return _resolve


def hf_url(file, rev=SHA, repo=REPO, host="huggingface.co"):
    return f"https://{host}/{repo}/resolve/{rev}/{file}"
