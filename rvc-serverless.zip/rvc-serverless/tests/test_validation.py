import unittest

from . import conftest_paths  # noqa: F401
from rvc_common.errors import RvcError
from rvc_common.settings import Settings
from rvc_common.validation import (parse_hf_url, parse_job_request, parse_model, parse_options, resolve_url,
                                   validate_job_id, validate_repo_file)
from .fakes import REPO, SHA, hf_url

S = Settings(allowed_repos=("alice/voices", "bob/*"))


def code_of(fn, *a, **k):
    try:
        fn(*a, **k)
    except RvcError as e:
        return e.code
    return None


class ModelTests(unittest.TestCase):
    def test_repo_mode(self):
        m = parse_model({"repo_id": REPO, "pth": "v/a.pth", "index": "v/a.index", "revision": SHA}, S)
        self.assertEqual((m.repo_id, m.pth, m.index, m.pinned), (REPO, "v/a.pth", "v/a.index", True))

    def test_index_optional_and_default_revision(self):
        m = parse_model({"repo_id": REPO, "pth": "a.pth"}, S)
        self.assertIsNone(m.index)
        self.assertEqual(m.revision, "main")

    def test_default_repo_used(self):
        s = Settings(allowed_repos=("alice/voices",), default_repo="alice/voices")
        self.assertEqual(parse_model({"pth": "a.pth"}, s).repo_id, "alice/voices")

    def test_fail_closed_when_allowlist_empty(self):
        self.assertEqual(code_of(parse_model, {"repo_id": REPO, "pth": "a.pth"}, Settings()), "MODEL_NOT_ALLOWED")

    def test_repo_not_allowed(self):
        self.assertEqual(code_of(parse_model, {"repo_id": "evil/x", "pth": "a.pth"}, S), "MODEL_NOT_ALLOWED")

    def test_owner_wildcard(self):
        self.assertEqual(parse_model({"repo_id": "bob/anything", "pth": "a.pth"}, S).repo_id, "bob/anything")
        self.assertEqual(code_of(parse_model, {"repo_id": "bobby/x", "pth": "a.pth"}, S), "MODEL_NOT_ALLOWED")

    def test_require_pinned(self):
        s = Settings(allowed_repos=("alice/voices",), require_pinned_revision=True)
        self.assertEqual(code_of(parse_model, {"repo_id": REPO, "pth": "a.pth"}, s), "REVISION_NOT_PINNED")
        self.assertEqual(code_of(parse_model, {"repo_id": REPO, "pth": "a.pth", "revision": "main"}, s),
                         "REVISION_NOT_PINNED")
        self.assertTrue(parse_model({"repo_id": REPO, "pth": "a.pth", "revision": SHA}, s).pinned)

    def test_bad_files(self):
        for bad in ["../a.pth", "/etc/a.pth", "a/../b.pth", "a\\b.pth", "a.pt", "a.pth/", "", None, "a/b/c/d/e/f/g.pth",
                    ".hidden.pth", "a%2f.pth", "x" * 300 + ".pth"]:
            self.assertEqual(code_of(validate_repo_file, bad, ".pth"), "INVALID_FILE", bad)

    def test_bad_repo_ids(self):
        for bad in ["noslash", "a/b/c", "../x", "a/..", "a b/c", "", "a/", "/a", None, 5]:
            self.assertIn(code_of(parse_model, {"repo_id": bad, "pth": "a.pth"}, S), ("INVALID_REPO_ID", "INVALID_MODEL"))

    def test_unknown_keys_rejected(self):
        self.assertEqual(code_of(parse_model, {"repo_id": REPO, "pth": "a.pth", "token": "x"}, S), "INVALID_MODEL")

    def test_sha_fields(self):
        m = parse_model({"repo_id": REPO, "pth": "a.pth", "pth_sha256": "AB" * 32}, S)
        self.assertEqual(m.pth_sha256, "ab" * 32)
        self.assertEqual(code_of(parse_model, {"repo_id": REPO, "pth": "a.pth", "pth_sha256": "zz"}, S), "INVALID_MODEL")


class UrlTests(unittest.TestCase):
    def test_good_url_and_query_stripped(self):
        host, repo, rev, f = parse_hf_url(hf_url("v/a.pth") + "?download=true", ("huggingface.co",))
        self.assertEqual((host, repo, rev, f), ("huggingface.co", REPO, SHA, "v/a.pth"))

    def test_blob_url_accepted(self):
        _, _, _, f = parse_hf_url(f"https://huggingface.co/{REPO}/blob/main/a.pth", ("huggingface.co",))
        self.assertEqual(f, "a.pth")

    def test_model_url_mode(self):
        m = parse_model({"url": hf_url("v/a.pth"), "index_url": hf_url("v/a.index")}, S)
        self.assertEqual((m.repo_id, m.revision, m.pth, m.index), (REPO, SHA, "v/a.pth", "v/a.index"))

    def test_url_repo_still_allowlisted(self):
        self.assertEqual(code_of(parse_model, {"url": hf_url("a.pth", repo="evil/x")}, S), "MODEL_NOT_ALLOWED")

    def test_index_url_must_match_repo(self):
        self.assertEqual(code_of(parse_model, {"url": hf_url("a.pth"), "index_url": hf_url("a.index", rev="b" * 40)}, S),
                         "INVALID_MODEL")

    def test_conflicting_fields(self):
        self.assertEqual(code_of(parse_model, {"url": hf_url("a.pth"), "pth": "other.pth"}, S), "INVALID_MODEL")

    def test_blocked_urls(self):
        bad = [
            "http://huggingface.co/a/b/resolve/main/x.pth",                    # http
            "https://huggingface.co.evil.com/a/b/resolve/main/x.pth",          # suffix trick
            "https://evilhuggingface.co/a/b/resolve/main/x.pth",
            "https://user:pw@huggingface.co/a/b/resolve/main/x.pth",           # credentials
            "https://huggingface.co:8443/a/b/resolve/main/x.pth",              # port
            "https://169.254.169.254/latest/meta-data/",                       # IMDS
            "https://10.0.0.5/a/b/resolve/main/x.pth",
            "https://[::1]/a/b/resolve/main/x.pth",
            "https://localhost/a/b/resolve/main/x.pth",
            "https://s3.amazonaws.com/bucket/x.pth",
            "https://huggingface.co/a/b/tree/main/x.pth",                      # wrong kind
            "https://huggingface.co/a/b/resolve/main",                         # no file
            "https://huggingface.co/a/b/resolve/main/..%2f..%2fx.pth",         # encoded traversal
            "https://huggingface.co/a/b/resolve/main/x%5cy.pth",
            "file:///etc/passwd", "ftp://huggingface.co/a/b/resolve/main/x.pth", "", None, 7,
            "https://huggingface.co/a/b/resolve/main/x.pth\n",
        ]
        for u in bad:
            self.assertEqual(code_of(parse_hf_url, u, ("huggingface.co",)), "URL_NOT_ALLOWED", u)

    def test_resolve_url_rebuilds_from_validated_parts(self):
        self.assertEqual(resolve_url("huggingface.co", REPO, SHA, "v/my model.pth"),
                         f"https://huggingface.co/alice/voices/resolve/{SHA}/v/my%20model.pth")


class OptionsAndJobTests(unittest.TestCase):
    def test_defaults(self):
        o = parse_options(None)
        self.assertEqual((o["pitch"], o["f0_method"], o["index_rate"]), (0, "rmvpe", 0.3))

    def test_ranges(self):
        for bad in [{"pitch": 99}, {"pitch": 1.5}, {"pitch": True}, {"index_rate": 2}, {"protect": 0.9},
                    {"f0_method": "custom"}, {"split_audio": "yes"}, {"embedder_model": "evil/model"},
                    {"index_rate": float("nan")}, {"sid": -1}]:
            self.assertEqual(code_of(parse_options, bad), "INVALID_OPTIONS", bad)

    def test_job_request_roundtrip(self):
        jr = parse_job_request({"model": {"repo_id": REPO, "pth": "a.pth"}, "options": {"pitch": 2}}, S)
        again = parse_job_request(jr.to_dict(), S)
        self.assertEqual(jr, again)

    def test_input_url_disabled_by_default(self):
        self.assertEqual(code_of(parse_job_request, {"model": {"repo_id": REPO, "pth": "a.pth"},
                                                      "input_url": "https://x.example.com/a.wav"}, S), "INPUT_URL_DISABLED")

    def test_input_url_allowlist(self):
        s = Settings(allowed_repos=("alice/voices",), allowed_input_hosts=("files.example.com",))
        ok = parse_job_request({"model": {"repo_id": REPO, "pth": "a.pth"},
                                "input_url": "https://files.example.com/a.wav?sig=1"}, s)
        self.assertIn("sig=1", ok.input_url)
        for bad in ["https://other.com/a.wav", "http://files.example.com/a.wav", "https://169.254.169.254/x",
                    "https://files.example.com:444/a.wav"]:
            self.assertEqual(code_of(parse_job_request, {"model": {"repo_id": REPO, "pth": "a.pth"}, "input_url": bad}, s),
                             "URL_NOT_ALLOWED", bad)

    def test_unknown_top_level(self):
        self.assertEqual(code_of(parse_job_request, {"model": {"repo_id": REPO, "pth": "a.pth"}, "x": 1}, S),
                         "INVALID_REQUEST")

    def test_job_id(self):
        self.assertEqual(validate_job_id("a" * 32), "a" * 32)
        for bad in ["", "../x", "A" * 32, "a" * 31, None, "a" * 32 + "/x"]:
            self.assertEqual(code_of(validate_job_id, bad), "INVALID_JOB_ID")


if __name__ == "__main__":
    unittest.main()
