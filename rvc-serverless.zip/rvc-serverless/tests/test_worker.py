import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from . import conftest_paths  # noqa: F401
from rvc_common import keys
from rvc_common.model_cache import ModelCache
from rvc_common.redaction import clear_secrets
from rvc_common.settings import Settings
from worker.audio import AudioInfo
from worker.worker import Deps, build_infer_command, run_job, scrubbed_env
from .fakes import (INDEX_BYTES, PTH_BYTES, REPO, SHA, FakeResponse, FakeS3, FakeSecrets, FakeTransport, resolver)

JOB = "c" * 32
MODEL_PATH = f"/{REPO}/resolve/{SHA}/"


class FakeAudio:
    def __init__(self, in_dur=10.0, out_dur=10.0, peak=-3.0):
        self.in_dur, self.out_dur, self.peak = in_dur, out_dur, peak

    def probe(self, path):
        d = self.out_dur if Path(path).name == "output.wav" else self.in_dur
        return AudioInfo(d, 44100, 1, "wav")

    def to_wav(self, src, dst, max_seconds):
        Path(dst).write_bytes(b"RIFFfake")

    def max_volume_db(self, path):
        return self.peak


class Runner:
    def __init__(self, write_output=True, returncode=0, stdout="File inferred successfully", timeout=False):
        self.calls, self.write_output, self.returncode = [], write_output, returncode
        self.stdout, self.timeout = stdout, timeout

    def __call__(self, cmd, **kw):
        self.calls.append((cmd, kw))
        if self.timeout:
            raise subprocess.TimeoutExpired(cmd, 1)
        if self.write_output:
            Path(cmd[cmd.index("--output-path") + 1]).write_bytes(b"RIFF" + b"\x00" * 500)
        return SimpleNamespace(returncode=self.returncode, stdout=self.stdout, stderr="")


class WorkerBase(unittest.TestCase):
    def setUp(self):
        clear_secrets()
        self.tmp = Path(tempfile.mkdtemp())
        self.s3 = FakeS3()
        self.kw = dict(bucket="b", allowed_repos=(REPO,), workdir_root=str(self.tmp / "work"),
                       applio_dir=str(self.tmp))
        self.routes = {("huggingface.co", MODEL_PATH + "a.pth"): FakeResponse(200, PTH_BYTES),
                       ("huggingface.co", MODEL_PATH + "a.index"): FakeResponse(200, INDEX_BYTES)}
        self.model = {"repo_id": REPO, "revision": SHA, "pth": "a.pth", "index": "a.index"}
        self.options = {}

    def submit(self, model=None, options=None, input_bytes=b"audio-bytes", input_url=None):
        req = {"model": model or self.model, "options": options or {}}
        if input_url:
            req["input_url"] = input_url
        self.s3.put(keys.job_key(JOB), {"request": req})
        if input_bytes is not None:
            self.s3.put(keys.input_key(JOB), input_bytes)

    def run_worker(self, runner=None, audio=None, **settings_kw):
        kw = {**self.kw, **settings_kw}
        self.runner = runner or Runner()
        self.transport = FakeTransport(dict(self.routes))
        deps = Deps(s3=self.s3, secrets_factory=lambda: self.secrets if hasattr(self, "secrets") else None,
                    transport=self.transport, resolver=resolver(), runner=self.runner,
                    audio=audio or FakeAudio(), environ=getattr(self, "environ", {"PATH": "/usr/bin"}),
                    sleep=lambda s: None, cache=getattr(self, "cache", None))
        return run_job(Settings(**kw), JOB, deps)

    def status(self):
        return json.loads(self.s3.store[keys.status_key(JOB)])


class SuccessPathTests(WorkerBase):
    def test_success_end_to_end(self):
        self.submit(options={"pitch": 2})
        doc = self.run_worker()
        self.assertEqual(doc["state"], "SUCCEEDED")
        self.assertIn(keys.output_key(JOB), self.s3.store)
        self.assertEqual(self.s3.upload_args[0][1], {"ContentType": "audio/wav"})
        self.assertEqual(self.status()["model"]["usedIndex"], True)
        self.assertEqual(self.status()["model"]["pthSha256"], doc["model"]["pthSha256"])
        self.assertIn(keys.input_key(JOB), self.s3.deleted)                 # input removed after the job
        self.assertFalse((self.tmp / "work" / JOB).exists())                # workdir cleaned

    def test_command_uses_hyphen_flags_fixed_paths_and_cwd(self):
        self.submit(options={"pitch": 2, "f0_method": "fcpe"})
        self.run_worker()
        cmd, kw = self.runner.calls[0]
        self.assertEqual(cmd[1:3], ["core.py", "infer"])
        for flag in ("--input-path", "--output-path", "--pth-path", "--index-path", "--index-rate", "--f0-method"):
            self.assertIn(flag, cmd)
        self.assertNotIn("--input_path", cmd)
        self.assertEqual(cmd[cmd.index("--pitch") + 1], "2")
        self.assertEqual(cmd[cmd.index("--f0-method") + 1], "fcpe")
        self.assertEqual(cmd[cmd.index("--embedder-model") + 1], "contentvec")
        self.assertTrue(cmd[cmd.index("--pth-path") + 1].endswith("/model/model.pth"))
        self.assertTrue(cmd[cmd.index("--index-path") + 1].endswith("/model/model.index"))
        self.assertEqual(kw["cwd"], str(self.tmp))
        self.assertTrue(all("trained" not in c for c in cmd))

    def test_user_text_never_reaches_command_line(self):
        self.model["pth"] = "voices/alice's voice (v2).pth"
        self.routes[("huggingface.co", MODEL_PATH + "voices/alice's")] = FakeResponse(200, PTH_BYTES)
        self.submit()
        doc = self.run_worker()          # invalid file name -> rejected during validation, nothing executed
        self.assertEqual(doc["state"], "FAILED")
        self.assertEqual(self.runner.calls, [])

    def test_no_index_forces_index_rate_zero(self):
        self.model.pop("index")
        self.submit(options={"index_rate": 0.8})
        doc = self.run_worker()
        self.assertEqual(doc["state"], "SUCCEEDED")
        cmd = self.runner.calls[0][0]
        self.assertEqual(cmd[cmd.index("--index-rate") + 1], "0")
        self.assertEqual(cmd[cmd.index("--index-path") + 1], "")
        self.assertEqual(len(self.transport.requests), 1)                   # only the .pth was downloaded
        self.assertFalse(doc["model"]["usedIndex"])

    def test_only_selected_model_files_are_downloaded(self):
        self.routes[("huggingface.co", f"/{REPO}/resolve/{SHA}/other.pth")] = FakeResponse(200, PTH_BYTES)
        self.submit()
        self.run_worker()
        targets = [r["target"] for r in self.transport.requests]
        self.assertEqual(sorted(targets), sorted([MODEL_PATH + "a.pth", MODEL_PATH + "a.index"]))

    def test_cache_hit_skips_download(self):
        self.cache = ModelCache(str(self.tmp / "cache"), 10**9, 3600)
        self.submit()
        self.run_worker()
        self.assertEqual(len(self.transport.requests), 2)
        self.submit()
        doc = self.run_worker()
        self.assertEqual(len(self.transport.requests), 0)
        self.assertEqual(doc["model"]["cacheHits"], 2)

    def test_keep_input_when_configured(self):
        self.submit()
        self.run_worker(delete_input_after_job=False)
        self.assertNotIn(keys.input_key(JOB), self.s3.deleted)


class FailureTests(WorkerBase):
    def assert_failed(self, code, **run_kw):
        doc = self.run_worker(**run_kw)
        self.assertEqual(doc["state"], "FAILED")
        self.assertEqual(doc["error"]["code"], code)
        self.assertEqual(self.status()["state"], "FAILED")
        self.assertNotIn(keys.output_key(JOB), self.s3.store)
        self.assertFalse((self.tmp / "work" / JOB).exists())
        self.assertIn(keys.input_key(JOB), self.s3.deleted)
        return doc

    def test_applio_exit_zero_but_error_marker_is_failure(self):
        self.submit()
        self.assert_failed("INFERENCE_FAILED", runner=Runner(stdout="Traceback...\nAn error occurred during inference"))

    def test_nonzero_exit(self):
        self.submit()
        self.assert_failed("INFERENCE_FAILED", runner=Runner(returncode=1))

    def test_exit_zero_but_no_output_file(self):
        self.submit()
        self.assert_failed("OUTPUT_MISSING", runner=Runner(write_output=False))

    def test_output_length_mismatch(self):
        self.submit()
        self.assert_failed("OUTPUT_INVALID", audio=FakeAudio(in_dur=10, out_dur=2))

    def test_silent_output(self):
        self.submit()
        self.assert_failed("OUTPUT_SILENT", audio=FakeAudio(peak=-91.0))

    def test_volume_undetectable_is_failure(self):
        self.submit()
        self.assert_failed("OUTPUT_SILENT", audio=FakeAudio(peak=None))

    def test_inference_timeout(self):
        self.submit()
        self.assert_failed("INFERENCE_TIMEOUT", runner=Runner(timeout=True))

    def test_input_too_long(self):
        self.submit()
        self.assert_failed("INPUT_TOO_LONG", audio=FakeAudio(in_dur=400), max_input_seconds=300)

    def test_missing_input(self):
        self.submit(input_bytes=None)
        self.assert_failed("INPUT_MISSING")

    def test_input_too_large(self):
        self.submit(input_bytes=b"x" * 2048)
        self.assert_failed("INPUT_TOO_LARGE", max_input_bytes=1024)

    def test_missing_job_definition(self):
        self.assert_failed("JOB_NOT_FOUND")

    def test_repo_not_allowed_is_rechecked_in_worker(self):
        self.submit()
        doc = self.run_worker(allowed_repos=("someone/else",))
        self.assertEqual(doc["error"]["code"], "MODEL_NOT_ALLOWED")
        self.assertEqual(self.transport.requests, [])
        self.assertEqual(self.runner.calls, [])

    def test_model_not_found(self):
        self.routes.clear()
        self.submit()
        self.assert_failed("DOWNLOAD_NOT_FOUND")

    def test_private_repo_without_token_reports_auth_failure(self):
        self.routes[("huggingface.co", MODEL_PATH + "a.pth")] = FakeResponse(401, b"")
        self.submit()
        self.assert_failed("MODEL_AUTH_FAILED")

    def test_model_too_large(self):
        self.submit()
        self.assert_failed("FILE_TOO_LARGE", max_pth_bytes=100)

    def test_unexpected_exception_is_generic(self):
        self.submit()

        class Boom(FakeAudio):
            def probe(self, path):
                raise RuntimeError("secret internals /var/x")
        doc = self.assert_failed("INTERNAL_ERROR", audio=Boom())
        self.assertNotIn("secret internals", json.dumps(doc))

    def test_bad_job_id_rejected(self):
        from rvc_common.errors import RvcError
        with self.assertRaises(RvcError):
            run_job(Settings(bucket="b"), "../etc", Deps(s3=self.s3))


class TokenTests(WorkerBase):
    ARN = "arn:aws:secretsmanager:us-east-1:111122223333:secret:hf-token-AbCdEf"

    def test_token_sent_only_to_hf_and_never_stored_or_logged(self):
        token = "hf_ABCDEFGHIJKLMNOPQRSTUV"
        self.secrets = FakeSecrets(json.dumps({"token": token}))
        self.submit()
        with self.assertLogs(level="DEBUG") as logs:
            import logging
            logging.getLogger("rvc.worker").info("probe")        # make assertLogs happy even if nothing else logs
            doc = self.run_worker(hf_token_secret_arn=self.ARN)
        self.assertEqual(doc["state"], "SUCCEEDED")
        self.assertEqual(self.secrets.calls, 1)                  # fetched once, cached in memory
        auths = [r["headers"].get("Authorization") for r in self.transport.requests]
        self.assertEqual(auths, ["Bearer " + token] * 2)
        blob = json.dumps({k: v.decode(errors="ignore") for k, v in self.s3.store.items()}) + "\n".join(logs.output)
        self.assertNotIn(token, blob)
        self.assertNotIn(self.ARN, json.dumps(doc))

    def test_plain_string_secret_supported(self):
        self.secrets = FakeSecrets("hf_PLAINSTRINGTOKEN12345")
        self.submit()
        self.run_worker(hf_token_secret_arn=self.ARN)
        self.assertEqual(self.transport.requests[0]["headers"]["Authorization"], "Bearer hf_PLAINSTRINGTOKEN12345")

    def test_no_secret_configured_means_anonymous(self):
        self.submit()
        self.run_worker()
        self.assertTrue(all("Authorization" not in r["headers"] for r in self.transport.requests))

    def test_unreadable_secret_fails_safely(self):
        class Broken:
            def get_secret_value(self, SecretId):
                raise RuntimeError(f"AccessDenied for {SecretId}")
        self.secrets = Broken()
        self.submit()
        doc = self.run_worker(hf_token_secret_arn=self.ARN)
        self.assertEqual(doc["error"]["code"], "SECRET_UNAVAILABLE")
        self.assertNotIn(self.ARN, json.dumps(doc))

    def test_inference_subprocess_gets_no_credentials(self):
        self.environ = {"PATH": "/usr/bin", "AWS_ACCESS_KEY_ID": "AKIA1", "AWS_SECRET_ACCESS_KEY": "s",
                        "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI": "/v2/credentials/x", "HF_TOKEN": "hf_x" * 5,
                        "NVIDIA_VISIBLE_DEVICES": "all", "SOME_OTHER": "1"}
        self.submit()
        self.run_worker()
        env = self.runner.calls[0][1]["env"]
        self.assertEqual(env["NVIDIA_VISIBLE_DEVICES"], "all")
        self.assertEqual(env["HF_HUB_OFFLINE"], "1")
        for k in env:
            self.assertFalse(k.startswith("AWS_"), k)
        self.assertNotIn("HF_TOKEN", env)
        self.assertNotIn("SOME_OTHER", env)


class InputUrlTests(WorkerBase):
    def test_input_url_downloaded_through_safe_fetcher(self):
        self.routes[("files.example.com", "/a.wav")] = FakeResponse(200, b"audio-from-url")
        self.submit(input_url="https://files.example.com/a.wav?sig=1", input_bytes=None)
        doc = self.run_worker(allowed_input_hosts=("files.example.com",))
        self.assertEqual(doc["state"], "SUCCEEDED")
        self.assertNotIn("Authorization", [h for r in self.transport.requests
                                           if r["host"] == "files.example.com" for h in r["headers"]])

    def test_input_url_private_ip_blocked(self):
        self.submit(input_url="https://files.example.com/a.wav", input_bytes=None)
        kw = {**self.kw, "allowed_input_hosts": ("files.example.com",)}
        deps = Deps(s3=self.s3, transport=FakeTransport(dict(self.routes)), resolver=resolver({"files.example.com": ["10.0.0.9"]}),
                    runner=Runner(), audio=FakeAudio(), environ={}, sleep=lambda s: None)
        doc = run_job(Settings(**kw), JOB, deps)
        self.assertEqual(doc["error"]["code"], "DOWNLOAD_BLOCKED")


class CommandBuilderTests(unittest.TestCase):
    OPTS = {"pitch": 0, "index_rate": 0.3, "volume_envelope": 1.0, "protect": 0.33, "f0_method": "rmvpe",
            "split_audio": False, "clean_audio": False, "clean_strength": 0.7, "sid": 0}

    def test_rejects_paths_containing_trained(self):
        from rvc_common.errors import RvcError
        with self.assertRaises(RvcError):
            build_infer_command("python", "/w/in.wav", "/w/out.wav", "/w/trained/model.pth", None, self.OPTS)

    def test_optional_flags(self):
        o = {**self.OPTS, "split_audio": True, "clean_audio": True}
        cmd = build_infer_command("python", "/w/in.wav", "/w/out.wav", "/w/model.pth", "/w/model.index", o)
        self.assertIn("--split-audio", cmd)
        self.assertIn("--clean-strength", cmd)

    def test_scrubbed_env_allowlist(self):
        env = scrubbed_env({"PATH": "/bin", "AWS_SESSION_TOKEN": "t", "CUDA_HOME": "/c", "X": "1"}, Path("/tmp/h"))
        self.assertEqual(sorted(k for k in env if k in ("PATH", "CUDA_HOME", "X", "AWS_SESSION_TOKEN")),
                         ["CUDA_HOME", "PATH"])


class RealFfmpegTests(unittest.TestCase):
    """Uses the local ffmpeg only to synthesise a 1-second tone; no model, no network."""

    @unittest.skipUnless(subprocess.run(["which", "ffmpeg"], capture_output=True).returncode == 0, "ffmpeg missing")
    def test_probe_convert_and_volume(self):
        from worker.audio import AudioTools
        tmp = Path(tempfile.mkdtemp())
        src, dst = tmp / "tone.flac", tmp / "out.wav"
        subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=1", "-y", str(src)],
                       check=True)
        tools = AudioTools()
        info = tools.probe(src)
        self.assertAlmostEqual(info.duration, 1.0, delta=0.1)
        tools.to_wav(src, dst, 300)
        out = tools.probe(dst)
        self.assertEqual((out.sample_rate, out.channels), (44100, 1))
        self.assertGreater(tools.max_volume_db(dst), -20)
        silent = tmp / "silent.wav"
        subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono", "-t", "1", "-y",
                        str(silent)], check=True)
        self.assertLess(tools.max_volume_db(silent), -60)

    @unittest.skipUnless(subprocess.run(["which", "ffmpeg"], capture_output=True).returncode == 0, "ffmpeg missing")
    def test_rejects_non_audio_and_playlists(self):
        from rvc_common.errors import RvcError
        from worker.audio import AudioTools
        tmp = Path(tempfile.mkdtemp())
        junk = tmp / "junk.raw"
        junk.write_bytes(b"not audio at all")
        playlist = tmp / "p.m3u8"
        playlist.write_text("#EXTM3U\n#EXTINF:1,\nhttp://169.254.169.254/latest/meta-data/\n")
        for f in (junk, playlist):
            with self.assertRaises(RvcError):
                AudioTools().probe(f)


if __name__ == "__main__":
    unittest.main()
