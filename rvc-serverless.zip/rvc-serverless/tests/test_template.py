"""Static checks on template.yaml (no AWS calls). They guard the cost/privacy guarantees in the README."""
import json
import os
import re
import unittest

import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class _Loader(yaml.SafeLoader):
    pass


def _multi(loader, suffix, node):
    if isinstance(node, yaml.ScalarNode):
        v = loader.construct_scalar(node)
    elif isinstance(node, yaml.SequenceNode):
        v = loader.construct_sequence(node, deep=True)
    else:
        v = loader.construct_mapping(node, deep=True)
    return {("Ref" if suffix == "Ref" else "Fn::" + suffix): v}


_Loader.add_multi_constructor("!", _multi)
with open(os.path.join(ROOT, "template.yaml")) as _fh:
    T = yaml.load(_fh, Loader=_Loader)
R, P = T["Resources"], T["Parameters"]


def of_type(t):
    return {k: v for k, v in R.items() if v["Type"] == t}


def walk(node):
    yield node
    if isinstance(node, dict):
        for v in node.values():
            yield from walk(v)
    elif isinstance(node, list):
        for v in node:
            yield from walk(v)


class CostGuardTests(unittest.TestCase):
    def test_gpu_compute_scales_to_zero_with_hard_cap(self):
        cr = R["ComputeEnvironment"]["Properties"]["ComputeResources"]
        self.assertEqual((cr["MinvCpus"], cr["DesiredvCpus"]), (0, 0))
        self.assertEqual(cr["MaxvCpus"], {"Ref": "MaxVCpus"})
        self.assertEqual(P["MaxVCpus"]["AllowedValues"], [4])
        self.assertEqual(cr["Type"], "EC2")                                # On-Demand, never SPOT
        self.assertNotIn("SPOT", json.dumps(cr))
        self.assertEqual(sorted(P["GpuInstanceType"]["AllowedValues"]), ["g4dn.xlarge", "g5.xlarge", "g6.xlarge"])

    def test_no_always_on_billable_resources(self):
        banned = {"AWS::EC2::NatGateway", "AWS::EC2::EIP", "AWS::EC2::VPCEndpoint", "AWS::DynamoDB::Table",
                  "AWS::RDS::DBInstance", "AWS::ElasticLoadBalancingV2::LoadBalancer", "AWS::KMS::Key",
                  "AWS::SecretsManager::Secret", "AWS::EC2::Instance", "AWS::AutoScaling::AutoScalingGroup"}
        self.assertEqual(banned & {v["Type"] for v in R.values()}, set())

    def test_no_job_retries_and_has_timeout(self):
        jd = R["JobDefinition"]["Properties"]
        self.assertEqual(jd["RetryStrategy"]["Attempts"], 1)
        self.assertIn("AttemptDurationSeconds", jd["Timeout"])
        self.assertIn({"Type": "GPU", "Value": "1"}, jd["ContainerProperties"]["ResourceRequirements"])

    def test_every_log_group_has_retention(self):
        groups = of_type("AWS::Logs::LogGroup")
        self.assertGreaterEqual(len(groups), 3)
        for name, g in groups.items():
            self.assertIn("RetentionInDays", g["Properties"], name)

    def test_ecr_has_lifecycle_scan_and_empty_on_delete(self):
        p = R["WorkerRepository"]["Properties"]
        self.assertTrue(p["ImageScanningConfiguration"]["ScanOnPush"])
        self.assertEqual(p["ImageTagMutability"], "IMMUTABLE")
        self.assertIn("LifecyclePolicy", p)
        self.assertTrue(p["EmptyOnDelete"])

    def test_root_volume_is_encrypted_and_deleted_with_instance(self):
        ebs = R["WorkerLaunchTemplate"]["Properties"]["LaunchTemplateData"]["BlockDeviceMappings"][0]["Ebs"]
        self.assertTrue(ebs["Encrypted"])
        self.assertTrue(ebs["DeleteOnTermination"])

    def test_egress_is_https_only_and_no_ingress(self):
        sg = R["WorkerSecurityGroup"]["Properties"]
        self.assertNotIn("SecurityGroupIngress", sg)
        self.assertEqual([(r["FromPort"], r["ToPort"]) for r in sg["SecurityGroupEgress"]], [(443, 443)])


class PrivacyTests(unittest.TestCase):
    def test_bucket_is_private_encrypted_and_expires_data(self):
        b = R["DataBucket"]["Properties"]
        self.assertTrue(all(b["PublicAccessBlockConfiguration"].values()))
        self.assertEqual(len(b["PublicAccessBlockConfiguration"]), 4)
        self.assertEqual(b["BucketEncryption"]["ServerSideEncryptionConfiguration"][0]
                         ["ServerSideEncryptionByDefault"]["SSEAlgorithm"], "AES256")
        rules = {r["Id"]: r for r in b["LifecycleConfiguration"]["Rules"]}
        self.assertEqual(rules["expire-input-audio"]["Prefix"], "inputs/")
        self.assertEqual(rules["expire-output-audio"]["Prefix"], "outputs/")
        self.assertEqual(rules["expire-job-metadata"]["Prefix"], "jobs/")
        self.assertIn("AbortIncompleteMultipartUpload", rules["abort-incomplete-uploads"])
        self.assertTrue(all(r["Status"] == "Enabled" for r in rules.values()))

    def test_tls_only_bucket_policy(self):
        st = R["DataBucketPolicy"]["Properties"]["PolicyDocument"]["Statement"][0]
        self.assertEqual((st["Effect"], st["Condition"]["Bool"]["aws:SecureTransport"]), ("Deny", "false"))

    def test_imds_not_reachable_from_containers(self):
        mo = R["WorkerLaunchTemplate"]["Properties"]["LaunchTemplateData"]["MetadataOptions"]
        self.assertEqual((mo["HttpTokens"], mo["HttpPutResponseHopLimit"]), ("required", 1))

    def test_no_secret_values_in_environment(self):
        envs = []
        for node in walk(T):
            if isinstance(node, dict) and "Environment" in node:
                e = node["Environment"]
                envs += [(x["Name"], x["Value"]) for x in e] if isinstance(e, list) else list(e["Variables"].items())
        self.assertTrue(envs)
        for name, value in envs:
            if re.search(r"TOKEN|SECRET|KEY|PASSWORD", name):
                self.assertEqual(name, "HF_TOKEN_SECRET_ARN")              # an ARN reference, never the token
                self.assertEqual(value, {"Ref": "HfTokenSecretArn"})

    def test_allowlist_has_no_default_so_it_fails_closed(self):
        self.assertNotIn("Default", P["AllowedHfRepos"])
        self.assertNotIn("Default", P["WorkerImageTag"])

    def test_api_has_no_anonymous_route(self):
        auth = R["HttpApi"]["Properties"]["Auth"]
        self.assertEqual((auth["DefaultAuthorizer"], auth["EnableIamAuthorizer"]), ("AWS_IAM", True))
        for ev in R["ApiFunction"]["Properties"]["Events"].values():
            self.assertNotIn("Auth", ev["Properties"])
        self.assertEqual(sorted((e["Properties"]["Method"], e["Properties"]["Path"])
                                for e in R["ApiFunction"]["Properties"]["Events"].values()),
                         [("GET", "/jobs/{jobId}"), ("POST", "/jobs"), ("POST", "/jobs/{jobId}/start")])

    def test_cache_is_off_by_default(self):
        self.assertEqual(P["EnableHostModelCache"]["Default"], "false")


class IamTests(unittest.TestCase):
    def statements(self):
        for name, r in of_type("AWS::IAM::Role").items():
            for pol in r["Properties"].get("Policies", []):
                for st in pol["PolicyDocument"]["Statement"]:
                    if isinstance(st, dict) and "Effect" in st:
                        yield name, st
                    elif isinstance(st, dict):                              # Fn::If wrapper
                        yield name, st["Fn::If"][1]

    def test_no_wildcard_actions_and_only_describe_jobs_uses_star_resource(self):
        for name, st in self.statements():
            actions = st["Action"] if isinstance(st["Action"], list) else [st["Action"]]
            for a in actions:
                self.assertNotIn("*", a, f"{name}: {a}")
            if st["Resource"] == "*":
                self.assertEqual(st["Action"], "batch:DescribeJobs")

    def test_no_admin_managed_policies(self):
        for r in of_type("AWS::IAM::Role").values():
            for arn in r["Properties"].get("ManagedPolicyArns", []):
                self.assertNotIn("Administrator", arn)
                self.assertNotIn("PowerUser", arn)

    def test_worker_cannot_touch_other_prefixes(self):
        resources = []
        for name, st in self.statements():
            if name == "JobRole" and st["Action"] in ("s3:GetObject", "s3:PutObject", "s3:DeleteObject"):
                resources += st["Resource"] if isinstance(st["Resource"], list) else [st["Resource"]]
        for r in resources:
            self.assertRegex(r["Fn::Sub"], r"/(inputs|jobs|outputs)/\*$")

    def test_secret_access_is_conditional_and_scoped(self):
        wrapped = [st for st in R["JobRole"]["Properties"]["Policies"][0]["PolicyDocument"]["Statement"]
                   if "Fn::If" in st]
        self.assertEqual(len(wrapped), 1)
        self.assertEqual(wrapped[0]["Fn::If"][0], "HasHfToken")
        self.assertEqual(wrapped[0]["Fn::If"][1]["Resource"], {"Ref": "HfTokenSecretArn"})


class ConsistencyTests(unittest.TestCase):
    def test_every_env_var_in_template_is_read_by_the_code(self):
        with open(os.path.join(ROOT, "src", "rvc_common", "settings.py")) as fh:
            settings_src = fh.read()
        known = set(re.findall(r'"([A-Z][A-Z0-9_]+)"', settings_src))
        used = set()
        for node in walk(T):
            if isinstance(node, dict) and "Environment" in node:
                e = node["Environment"]
                used |= {x["Name"] for x in e} if isinstance(e, list) else set(e["Variables"])
        self.assertEqual(used - known, set())

    def test_no_secrets_committed(self):
        pat = re.compile(r"hf_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN [A-Z ]*PRIVATE KEY-----")
        for base, dirs, files in os.walk(ROOT):
            dirs[:] = [d for d in dirs if d not in (".git", "tests", "__pycache__")]
            for f in files:
                if f.endswith((".py", ".yaml", ".md", ".txt", ".gitignore")) or f == "Dockerfile":
                    with open(os.path.join(base, f), errors="ignore") as fh:
                        text = fh.read()
                    self.assertIsNone(pat.search(text), os.path.join(base, f))


if __name__ == "__main__":
    unittest.main()
