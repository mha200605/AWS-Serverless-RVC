import json
import logging
import os
import tempfile
import unittest
from pathlib import Path

from . import conftest_paths  # noqa: F401
from rvc_common.model_cache import ModelCache, cache_key
from rvc_common.model_source import ModelDownloader
from rvc_common.redaction import RedactingFormatter, clear_secrets, redact, register_secret
from rvc_common.settings import Settings
from rvc_common.validation import ModelSpec
from .fakes import INDEX_BYTES, PTH_BYTES, REPO, SHA, FakeResponse, FakeTransport, resolver


class CacheTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp())
        self.t = [1000.0]
        self.cache = ModelCache(str(self.root / "c"), max_bytes=10_000, ttl_seconds=100, clock=lambda: self.t[0])
        self.src = self.root / "src.bin"
        self.src.write_bytes(b"A" * 3000)

    def test_dir_permissions(self):
        self.assertEqual(oct((self.root / "c").stat().st_mode & 0o777), "0o700")

    def test_store_and_lookup(self):
        k = cache_key("h", "a/b", SHA, "x.pth")
        self.assertIsNone(self.cache.lookup(k, self.root / "out"))
        self.cache.store(k, self.src, "deadbeef")
        # wrong stored hash => integrity check fails => entry discarded
        self.assertIsNone(self.cache.lookup(k, self.root / "out"))
        import hashlib
        self.cache.store(k, self.src, hashlib.sha256(self.src.read_bytes()).hexdigest())
        self.assertIsNotNone(self.cache.lookup(k, self.root / "out"))
        self.assertEqual((self.root / "out").read_bytes(), self.src.read_bytes())

    def test_corruption_detected_and_removed(self):
        import hashlib
        k = cache_key("h", "a/b", SHA, "x.pth")
        self.cache.store(k, self.src, hashlib.sha256(self.src.read_bytes()).hexdigest())
        (self.root / "c" / k / "data").write_bytes(b"B" * 3000)
        self.assertIsNone(self.cache.lookup(k, self.root / "out"))
        self.assertFalse((self.root / "c" / k).exists())

    def test_prune_ttl_then_size(self):
        for i in range(4):
            self.t[0] += 10
            self.cache.store(f"k{i}", self.src, "s")
        self.t[0] += 105         # ages are now 145/135/125/115s (> ttl of 100) -> all expired
        self.assertEqual(self.cache.prune(), 4)
        for i in range(4):
            self.t[0] += 1
            self.cache.store(f"n{i}", self.src, "s")      # 4*3000 = 12000 > 10000 limit
        self.assertEqual(self.cache.prune(), 1)
        self.assertFalse((self.root / "c" / "n0").exists())   # oldest evicted first
        self.assertTrue((self.root / "c" / "n3").exists())


class DownloaderCacheTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.settings = Settings(allowed_repos=(REPO,))
        self.routes = {("huggingface.co", f"/{REPO}/resolve/{SHA}/a.pth"): FakeResponse(200, PTH_BYTES),
                       ("huggingface.co", f"/{REPO}/resolve/{SHA}/a.index"): FakeResponse(200, INDEX_BYTES)}

    def dl(self, cache=None):
        t = FakeTransport(dict(self.routes))
        return ModelDownloader(self.settings, transport=t, resolver=resolver(), cache=cache, sleep=lambda s: None), t

    def test_pinned_revision_is_cached_unpinned_is_not(self):
        cache = ModelCache(str(self.tmp / "c"), 10**9, 3600)
        spec = ModelSpec(REPO, SHA, "a.pth", "a.index")
        d, t = self.dl(cache)
        r1 = d.fetch_model(spec, self.tmp / "j1")
        self.assertEqual((r1.cache_hits, len(t.requests)), (0, 2))
        d2, t2 = self.dl(cache)
        r2 = d2.fetch_model(spec, self.tmp / "j2")
        self.assertEqual((r2.cache_hits, len(t2.requests)), (2, 0))
        self.assertEqual(r2.pth_sha256, r1.pth_sha256)
        # unpinned ("main"): never cached, so a second job downloads again
        self.routes = {("huggingface.co", f"/{REPO}/resolve/main/a.pth"): FakeResponse(200, PTH_BYTES)}
        d3, t3 = self.dl(cache)
        d3.fetch_model(ModelSpec(REPO, "main", "a.pth"), self.tmp / "j3")
        self.routes = {("huggingface.co", f"/{REPO}/resolve/main/a.pth"): FakeResponse(200, PTH_BYTES)}
        d4, t4 = self.dl(cache)
        r4 = d4.fetch_model(ModelSpec(REPO, "main", "a.pth"), self.tmp / "j4")
        self.assertEqual((r4.cache_hits, len(t4.requests)), (0, 1))

    def test_no_index_downloads_only_pth(self):
        d, t = self.dl()
        r = d.fetch_model(ModelSpec(REPO, SHA, "a.pth"), self.tmp / "j")
        self.assertIsNone(r.index_path)
        self.assertEqual(len(t.requests), 1)

    def test_local_names_are_fixed(self):
        d, _ = self.dl()
        r = d.fetch_model(ModelSpec(REPO, SHA, "a.pth", "a.index"), self.tmp / "j")
        self.assertEqual((r.pth_path.name, r.index_path.name), ("model.pth", "model.index"))

    def test_html_error_page_rejected(self):
        self.routes[("huggingface.co", f"/{REPO}/resolve/{SHA}/a.pth")] = FakeResponse(200, b"<html>login</html>")
        d, _ = self.dl()
        from rvc_common.errors import RvcError
        with self.assertRaises(RvcError) as cm:
            d.fetch_model(ModelSpec(REPO, SHA, "a.pth"), self.tmp / "j")
        self.assertEqual(cm.exception.code, "INVALID_MODEL_FILE")

    def test_lfs_pointer_rejected_for_index(self):
        self.routes[("huggingface.co", f"/{REPO}/resolve/{SHA}/a.index")] = FakeResponse(
            200, b"version https://git-lfs.github.com/spec/v1\noid sha256:abc\n")
        d, _ = self.dl()
        from rvc_common.errors import RvcError
        with self.assertRaises(RvcError) as cm:
            d.fetch_model(ModelSpec(REPO, SHA, "a.pth", "a.index"), self.tmp / "j")
        self.assertEqual(cm.exception.code, "INVALID_MODEL_FILE")

    def test_size_limits_per_file_type(self):
        self.settings = Settings(allowed_repos=(REPO,), max_pth_bytes=100)
        d, _ = self.dl()
        from rvc_common.errors import RvcError
        with self.assertRaises(RvcError) as cm:
            d.fetch_model(ModelSpec(REPO, SHA, "a.pth"), self.tmp / "j")
        self.assertEqual(cm.exception.code, "FILE_TOO_LARGE")


class RedactionTests(unittest.TestCase):
    def tearDown(self):
        clear_secrets()

    def test_patterns(self):
        for s in ["token hf_abcdefghijklmnop1234 end", "Authorization: Bearer abc.def-ghi_jkl",
                  "url?X-Amz-Signature=deadbeef&x=1", "AWSAccessKeyId=AKIAXXXX&Signature=y"]:
            out = redact(s)
            self.assertIn("[REDACTED]", out, s)
            for leak in ["abcdefghijklmnop1234", "abc.def-ghi_jkl", "deadbeef", "AKIAXXXX"]:
                self.assertNotIn(leak, out)

    def test_registered_secret_scrubbed_even_without_pattern(self):
        register_secret("plain-secret-value")
        self.assertNotIn("plain-secret-value", redact("oops plain-secret-value leaked"))

    def test_formatter_redacts_exception_text(self):
        register_secret("topsecret123")
        rec = logging.LogRecord("x", logging.ERROR, __file__, 1, "msg %s", ("topsecret123",), None)
        try:
            raise ValueError("boom topsecret123")
        except ValueError:
            import sys
            rec.exc_info = sys.exc_info()
        self.assertNotIn("topsecret123", RedactingFormatter("%(message)s").format(rec))


if __name__ == "__main__":
    unittest.main()
