"""Error type whose message is ALWAYS safe to show to an API client.

Never put tokens, signed URLs, internal hostnames or stack traces in `message`.
"""


class RvcError(Exception):
    def __init__(self, code: str, message: str, *, retryable: bool = False, http_status: int = 400):
        super().__init__(message)
        self.code = code
        self.message = message
        self.retryable = retryable
        self.http_status = http_status

    def to_dict(self) -> dict:
        return {"code": self.code, "message": self.message}
