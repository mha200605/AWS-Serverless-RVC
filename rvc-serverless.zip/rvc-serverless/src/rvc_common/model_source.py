"""Download exactly the selected model (.pth + optional .index) from Hugging Face."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from .errors import RvcError
from .model_cache import ModelCache, cache_key
from .net import FetchPolicy, SafeFetcher
from .settings import Settings
from .validation import ModelSpec, resolve_url

PTH_NAME = "model.pth"        # fixed local names: user-supplied file names never reach the filesystem
INDEX_NAME = "model.index"


def _pth_head_ok(head: bytes) -> None:
    # torch zip archive ("PK\x03\x04") or legacy pickle (0x80). Catches HTML error pages / LFS pointers.
    if not (head.startswith(b"PK\x03\x04") or head[:1] == b"\x80"):
        raise RvcError("INVALID_MODEL_FILE", "The .pth file does not look like a PyTorch checkpoint.")


def _index_head_ok(head: bytes) -> None:
    low = head[:256].lower()
    if low.lstrip().startswith(b"<") or b"<html" in low or low.startswith(b"version https://git-lfs"):
        raise RvcError("INVALID_MODEL_FILE", "The .index file does not look like a FAISS index.")


@dataclass
class ModelFiles:
    pth_path: Path
    index_path: Optional[Path]
    pth_sha256: str
    index_sha256: Optional[str]
    cache_hits: int


class ModelDownloader:
    def __init__(self, settings: Settings, *, transport=None, resolver=None, cache: Optional[ModelCache] = None,
                 clock=None, sleep=None):
        kwargs = {k: v for k, v in (("transport", transport), ("resolver", resolver),
                                    ("clock", clock), ("sleep", sleep)) if v is not None}
        self.settings = settings
        self.cache = cache
        self.fetcher = SafeFetcher(FetchPolicy(
            allowed_hosts=settings.allowed_download_hosts,
            redirect_suffixes=settings.redirect_host_suffixes,
            token_hosts=settings.allowed_download_hosts,
            socket_timeout=settings.socket_timeout_seconds,
            total_timeout=settings.download_timeout_seconds,
        ), **kwargs)

    def _one(self, spec: ModelSpec, file: str, dest: Path, max_bytes: int, expected: Optional[str],
             head_ok: Callable, token_provider) -> tuple:
        use_cache = self.cache is not None and spec.pinned
        key = cache_key(spec.host, spec.repo_id, spec.revision, file) if use_cache else None
        if use_cache:
            meta = self.cache.lookup(key, dest)
            if meta and (not expected or meta["sha256"] == expected) and meta["size"] <= max_bytes:
                return meta["sha256"], True
        res = self.fetcher.fetch(resolve_url(spec.host, spec.repo_id, spec.revision, file), dest,
                                 max_bytes=max_bytes, token_provider=token_provider,
                                 expected_sha256=expected, head_validator=head_ok)
        if use_cache:
            self.cache.store(key, dest, res.sha256)
        return res.sha256, False

    def fetch_model(self, spec: ModelSpec, dest_dir: Path, token_provider: Optional[Callable[[], str]] = None
                    ) -> ModelFiles:
        dest_dir = Path(dest_dir)
        dest_dir.mkdir(parents=True, exist_ok=True)
        s = self.settings
        pth = dest_dir / PTH_NAME
        pth_sha, hit1 = self._one(spec, spec.pth, pth, s.max_pth_bytes, spec.pth_sha256, _pth_head_ok, token_provider)
        index, index_sha, hit2 = None, None, False
        if spec.index:
            index = dest_dir / INDEX_NAME
            index_sha, hit2 = self._one(spec, spec.index, index, s.max_index_bytes, spec.index_sha256,
                                        _index_head_ok, token_provider)
        return ModelFiles(pth, index, pth_sha, index_sha, int(hit1) + int(hit2))
