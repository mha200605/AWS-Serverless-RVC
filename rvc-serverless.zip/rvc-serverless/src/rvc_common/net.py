"""SSRF-resistant, size-limited, time-limited HTTPS downloader (stdlib only).

Defences, each covered by tests:
  * https only, port 443 only, no credentials in the URL, no IP-literal hosts
  * first hop must be in `allowed_hosts`; redirects must stay inside `redirect_suffixes`
  * every hop is resolved and ALL addresses must be globally routable (blocks 10/8, 127/8,
    169.254.169.254 IMDS, link-local, ULA, ...); the TCP connection is then pinned to the
    validated IP so DNS rebinding between check and connect is not possible
  * the Authorization header is attached only to hosts in `token_hosts` -- never to CDN redirects
  * Content-Length is checked up front and bytes are counted while streaming
  * socket timeout per read plus an overall deadline; bounded retries on 5xx/network errors
  * data goes to `<dest>.part` (0600) and is renamed only after all checks pass
"""
from __future__ import annotations

import hashlib
import http.client
import ipaddress
import os
import shutil
import socket
import ssl
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import urljoin, urlsplit

from .errors import RvcError

CHUNK = 1024 * 1024
REDIRECT_CODES = (301, 302, 303, 307, 308)
DISK_MARGIN = 256 * 1024 * 1024


@dataclass(frozen=True)
class FetchPolicy:
    allowed_hosts: tuple
    redirect_suffixes: tuple = ()
    token_hosts: tuple = ()
    socket_timeout: int = 30
    total_timeout: int = 600
    max_redirects: int = 5
    retries: int = 2


@dataclass
class FetchResult:
    size: int
    sha256: str
    final_host: str


def resolve_public_ips(host: str, getaddrinfo=socket.getaddrinfo) -> list:
    try:
        infos = getaddrinfo(host, 443, type=socket.SOCK_STREAM)
    except OSError:
        raise RvcError("DOWNLOAD_FAILED", "Could not resolve download host.", retryable=True)
    ips = []
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if getattr(ip, "ipv4_mapped", None):
            ip = ip.ipv4_mapped
        if not ip.is_global:
            raise RvcError("DOWNLOAD_BLOCKED", "Download target is not permitted.")
        if str(ip) not in ips:
            ips.append(str(ip))
    if not ips:
        raise RvcError("DOWNLOAD_FAILED", "Could not resolve download host.", retryable=True)
    return ips


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    """TLS connection that dials a pre-validated IP but verifies the certificate for `host`."""

    def __init__(self, host, ip, port, timeout):
        super().__init__(host, port, timeout=timeout, context=ssl.create_default_context())
        self._pinned_ip = ip

    def connect(self):
        sock = socket.create_connection((self._pinned_ip, self.port), self.timeout)
        self.sock = self._context.wrap_socket(sock, server_hostname=self.host)


class _Response:
    def __init__(self, conn, resp):
        self._conn, self._resp = conn, resp
        self.status = resp.status

    def getheader(self, name, default=None):
        return self._resp.getheader(name, default)

    def read(self, n):
        return self._resp.read(n)

    def close(self):
        try:
            self._resp.close()
        finally:
            self._conn.close()


class PinnedTransport:
    def request(self, host, ip, port, target, headers, timeout):
        conn = _PinnedHTTPSConnection(host, ip, port, timeout)
        try:
            conn.request("GET", target, headers=headers)
            return _Response(conn, conn.getresponse())
        except BaseException:
            conn.close()
            raise


def _suffix_match(host: str, suffixes: tuple) -> bool:
    return any(host == s or host.endswith("." + s) for s in suffixes)


class SafeFetcher:
    def __init__(self, policy: FetchPolicy, *, transport=None, resolver=resolve_public_ips,
                 clock=time.monotonic, sleep=time.sleep):
        self.policy = policy
        self.transport = transport or PinnedTransport()
        self.resolver = resolver
        self.clock = clock
        self.sleep = sleep

    # -- public ---------------------------------------------------------
    def fetch(self, url: str, dest: Path, *, max_bytes: int, token_provider: Optional[Callable[[], str]] = None,
              expected_sha256: Optional[str] = None, head_validator: Optional[Callable[[bytes], None]] = None
              ) -> FetchResult:
        dest = Path(dest)
        deadline = self.clock() + self.policy.total_timeout
        attempt = 0
        while True:
            try:
                return self._attempt(url, dest, max_bytes, token_provider, expected_sha256, head_validator, deadline)
            except RvcError as exc:
                attempt += 1
                if not exc.retryable or attempt > self.policy.retries or self.clock() >= deadline:
                    raise
                self.sleep(min(2 ** attempt, 8))

    # -- internals ------------------------------------------------------
    def _check_url(self, url: str, hop: int):
        blocked = RvcError("DOWNLOAD_BLOCKED", "Download target is not permitted.")
        try:
            parts = urlsplit(url)
            host, port = (parts.hostname or "").lower(), parts.port
        except ValueError:
            raise blocked
        if parts.scheme != "https" or not host or parts.username is not None or parts.password is not None:
            raise blocked
        if port not in (None, 443):
            raise blocked
        try:
            ipaddress.ip_address(host.strip("[]"))
            raise blocked                                    # IP literals are never allowed
        except ValueError:
            pass
        ok = host in self.policy.allowed_hosts or (hop > 0 and _suffix_match(host, self.policy.redirect_suffixes))
        if not ok:
            raise blocked
        target = (parts.path or "/") + (("?" + parts.query) if parts.query else "")
        return host, target

    def _attempt(self, url, dest, max_bytes, token_provider, expected_sha256, head_validator, deadline):
        current, hop = url, 0
        while True:
            host, target = self._check_url(current, hop)
            ips = self.resolver(host)
            headers = {"Host": host, "User-Agent": "rvc-serverless/1.0", "Accept-Encoding": "identity"}
            if token_provider and host in self.policy.token_hosts:
                token = token_provider()
                if token:
                    headers["Authorization"] = "Bearer " + token
            try:
                resp = self.transport.request(host, ips[0], 443, target, headers, self.policy.socket_timeout)
            except (socket.timeout, TimeoutError):
                raise RvcError("DOWNLOAD_TIMEOUT", "Download timed out.", retryable=True)
            except (OSError, http.client.HTTPException):
                raise RvcError("DOWNLOAD_FAILED", "Download connection failed.", retryable=True)
            if resp.status in REDIRECT_CODES:
                location = resp.getheader("Location")
                resp.close()
                hop += 1
                if not location or hop > self.policy.max_redirects:
                    raise RvcError("DOWNLOAD_FAILED", "Too many or invalid redirects.")
                current = urljoin(current, location)
                continue
            break
        try:
            return self._consume(resp, host, dest, max_bytes, expected_sha256, head_validator, deadline)
        finally:
            resp.close()

    def _consume(self, resp, host, dest, max_bytes, expected_sha256, head_validator, deadline) -> FetchResult:
        status = resp.status
        if status in (401, 403):
            raise RvcError("MODEL_AUTH_FAILED", "Access denied: the repository is private or the token lacks access.")
        if status == 404:
            raise RvcError("DOWNLOAD_NOT_FOUND", "File or repository not found (or not visible to the configured token).")
        if status == 429 or status >= 500:
            raise RvcError("DOWNLOAD_UNAVAILABLE", "Remote server is unavailable; try again later.", retryable=True)
        if status != 200:
            raise RvcError("DOWNLOAD_FAILED", f"Unexpected response status {status}.")

        declared = resp.getheader("Content-Length")
        declared_n = None
        if declared is not None:
            try:
                declared_n = int(declared)
            except ValueError:
                raise RvcError("DOWNLOAD_FAILED", "Invalid Content-Length from server.")
            if declared_n > max_bytes:
                raise RvcError("FILE_TOO_LARGE", "File exceeds the allowed size limit.")
        dest.parent.mkdir(parents=True, exist_ok=True)
        need = (declared_n if declared_n is not None else max_bytes) + DISK_MARGIN
        if shutil.disk_usage(dest.parent).free < need:
            raise RvcError("INSUFFICIENT_DISK", "Not enough local disk space for this download.")

        part = dest.with_name(dest.name + ".part")
        digest, total, head = hashlib.sha256(), 0, b""
        fd = os.open(part, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        try:
            with os.fdopen(fd, "wb") as fh:
                while True:
                    if self.clock() >= deadline:
                        raise RvcError("DOWNLOAD_TIMEOUT", "Download exceeded the time limit.", retryable=True)
                    try:
                        chunk = resp.read(CHUNK)
                    except (socket.timeout, TimeoutError):
                        raise RvcError("DOWNLOAD_TIMEOUT", "Download timed out.", retryable=True)
                    except (OSError, http.client.HTTPException):
                        raise RvcError("DOWNLOAD_FAILED", "Download connection failed.", retryable=True)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > max_bytes:
                        raise RvcError("FILE_TOO_LARGE", "File exceeds the allowed size limit.")
                    if len(head) < 512:
                        head += chunk[: 512 - len(head)]
                    digest.update(chunk)
                    fh.write(chunk)
            if total == 0:
                raise RvcError("DOWNLOAD_FAILED", "Downloaded file is empty.")
            if declared_n is not None and total != declared_n:
                raise RvcError("DOWNLOAD_FAILED", "Download was truncated.", retryable=True)
            if head_validator:
                head_validator(head)
            sha = digest.hexdigest()
            if expected_sha256 and sha != expected_sha256.lower():
                raise RvcError("CHECKSUM_MISMATCH", "Downloaded file does not match the expected SHA-256.")
            os.replace(part, dest)
            return FetchResult(size=total, sha256=sha, final_host=host)
        finally:
            try:
                os.unlink(part)
            except FileNotFoundError:
                pass
