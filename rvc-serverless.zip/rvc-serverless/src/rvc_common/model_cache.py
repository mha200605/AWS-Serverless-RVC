"""Optional on-disk model cache with an explicit cleanup policy.

Only commit-SHA-pinned revisions are cacheable (a branch like `main` can change under us).
Every reuse re-hashes the file, so a corrupted/tampered entry is discarded, not trusted.
Policy: entries unused for `ttl_seconds` are deleted; then least-recently-used entries are
deleted until the total is <= `max_bytes`. Directory is 0700. Disabled when no directory is set.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
from pathlib import Path
from typing import Optional


def cache_key(host: str, repo_id: str, revision: str, file: str) -> str:
    return hashlib.sha256("\0".join([host, repo_id, revision, file]).encode()).hexdigest()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class ModelCache:
    def __init__(self, root: str, max_bytes: int, ttl_seconds: int, clock=time.time):
        self.root = Path(root)
        self.max_bytes = max_bytes
        self.ttl = ttl_seconds
        self.clock = clock
        self.root.mkdir(parents=True, exist_ok=True)
        os.chmod(self.root, 0o700)

    def _dir(self, key: str) -> Path:
        return self.root / key

    def lookup(self, key: str, dest: Path) -> Optional[dict]:
        d = self._dir(key)
        meta_path, data = d / "meta.json", d / "data"
        try:
            meta = json.loads(meta_path.read_text())
            if data.stat().st_size != meta["size"] or _sha256_file(data) != meta["sha256"]:
                raise ValueError("integrity")
        except (OSError, ValueError, KeyError):
            shutil.rmtree(d, ignore_errors=True)
            return None
        shutil.copyfile(data, dest)
        os.chmod(dest, 0o600)
        meta["last_used"] = self.clock()
        meta_path.write_text(json.dumps(meta))
        return meta

    def store(self, key: str, src: Path, sha256: str) -> None:
        d = self._dir(key)
        tmp = self.root / f".tmp-{key}-{os.getpid()}"
        shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(mode=0o700)
        shutil.copyfile(src, tmp / "data")
        size = (tmp / "data").stat().st_size
        (tmp / "meta.json").write_text(json.dumps({"size": size, "sha256": sha256, "last_used": self.clock()}))
        shutil.rmtree(d, ignore_errors=True)
        os.replace(tmp, d)

    def prune(self) -> int:
        """Apply the cleanup policy. Returns number of entries removed."""
        now, removed, entries = self.clock(), 0, []
        for d in self.root.iterdir():
            if d.name.startswith(".tmp-"):
                shutil.rmtree(d, ignore_errors=True)
                continue
            try:
                meta = json.loads((d / "meta.json").read_text())
                entries.append((meta["last_used"], meta["size"], d))
            except (OSError, ValueError, KeyError):
                shutil.rmtree(d, ignore_errors=True)
                removed += 1
        keep = []
        for last_used, size, d in entries:
            if now - last_used > self.ttl:
                shutil.rmtree(d, ignore_errors=True)
                removed += 1
            else:
                keep.append((last_used, size, d))
        keep.sort()                                           # oldest first
        total = sum(s for _, s, _ in keep)
        while keep and total > self.max_bytes:
            _, size, d = keep.pop(0)
            shutil.rmtree(d, ignore_errors=True)
            total -= size
            removed += 1
        return removed
