"""Shared, stdlib-only code used by both the API Lambda and the GPU worker."""
