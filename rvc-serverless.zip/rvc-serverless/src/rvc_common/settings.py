"""Configuration, read from environment variables (set by template.yaml)."""
from __future__ import annotations

import os
from dataclasses import dataclass

MiB = 1024 * 1024


def _csv(value: str) -> tuple:
    return tuple(p.strip().lower() for p in (value or "").split(",") if p.strip())


def _int(env, name, default, lo=None, hi=None) -> int:
    raw = env.get(name)
    if raw in (None, ""):
        return default
    try:
        val = int(raw)
    except ValueError:
        raise ValueError(f"{name} must be an integer")
    if (lo is not None and val < lo) or (hi is not None and val > hi):
        raise ValueError(f"{name} out of range")
    return val


def _bool(env, name, default=False) -> bool:
    raw = env.get(name)
    if raw in (None, ""):
        return default
    return str(raw).strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Settings:
    bucket: str = ""
    # --- model sources -------------------------------------------------
    allowed_repos: tuple = ()                 # "owner/repo" or "owner/*"; EMPTY = nothing allowed (fail closed)
    default_repo: str = ""
    require_pinned_revision: bool = False     # require a 40-hex commit SHA
    allowed_download_hosts: tuple = ("huggingface.co",)
    redirect_host_suffixes: tuple = ("hf.co", "huggingface.co")
    hf_token_secret_arn: str = ""
    max_pth_bytes: int = 512 * MiB
    max_index_bytes: int = 1024 * MiB
    # --- input audio ---------------------------------------------------
    allowed_input_hosts: tuple = ()           # EMPTY = `input_url` feature disabled
    max_input_bytes: int = 50 * MiB
    max_input_seconds: int = 300
    # --- timeouts ------------------------------------------------------
    download_timeout_seconds: int = 600
    socket_timeout_seconds: int = 30
    infer_timeout_seconds: int = 600
    # --- cache / cleanup ----------------------------------------------
    model_cache_dir: str = ""                 # EMPTY = caching disabled
    model_cache_max_bytes: int = 4096 * MiB
    model_cache_ttl_seconds: int = 86400
    delete_input_after_job: bool = True
    # --- worker --------------------------------------------------------
    applio_dir: str = "/app/applio"
    workdir_root: str = "/tmp/rvc"
    # --- api -----------------------------------------------------------
    job_queue: str = ""
    job_definition: str = ""
    upload_expiry_seconds: int = 900
    result_url_expiry_seconds: int = 300

    @classmethod
    def from_env(cls, env=None) -> "Settings":
        env = os.environ if env is None else env
        hosts = _csv(env.get("ALLOWED_DOWNLOAD_HOSTS", "")) or ("huggingface.co",)
        suffixes = _csv(env.get("ALLOWED_REDIRECT_HOST_SUFFIXES", "")) or ("hf.co", "huggingface.co")
        return cls(
            bucket=env.get("BUCKET", ""),
            allowed_repos=_csv(env.get("ALLOWED_HF_REPOS", "")),
            default_repo=(env.get("DEFAULT_HF_REPO", "") or "").strip(),
            require_pinned_revision=_bool(env, "REQUIRE_PINNED_REVISION"),
            allowed_download_hosts=hosts,
            redirect_host_suffixes=suffixes,
            hf_token_secret_arn=env.get("HF_TOKEN_SECRET_ARN", ""),
            max_pth_bytes=_int(env, "MAX_PTH_MB", 512, 1, 4096) * MiB,
            max_index_bytes=_int(env, "MAX_INDEX_MB", 1024, 1, 8192) * MiB,
            allowed_input_hosts=_csv(env.get("ALLOWED_INPUT_HOSTS", "")),
            max_input_bytes=_int(env, "MAX_INPUT_MB", 50, 1, 500) * MiB,
            max_input_seconds=_int(env, "MAX_INPUT_SECONDS", 300, 1, 3600),
            download_timeout_seconds=_int(env, "DOWNLOAD_TIMEOUT_SECONDS", 600, 10, 3600),
            socket_timeout_seconds=_int(env, "SOCKET_TIMEOUT_SECONDS", 30, 1, 300),
            infer_timeout_seconds=_int(env, "INFER_TIMEOUT_SECONDS", 600, 10, 3600),
            model_cache_dir=env.get("MODEL_CACHE_DIR", ""),
            model_cache_max_bytes=_int(env, "MODEL_CACHE_MAX_MB", 4096, 1, 102400) * MiB,
            model_cache_ttl_seconds=_int(env, "MODEL_CACHE_TTL_SECONDS", 86400, 60, 30 * 86400),
            delete_input_after_job=_bool(env, "DELETE_INPUT_AFTER_JOB", True),
            applio_dir=env.get("APPLIO_DIR", "/app/applio"),
            workdir_root=env.get("WORKDIR_ROOT", "/tmp/rvc"),
            job_queue=env.get("JOB_QUEUE", ""),
            job_definition=env.get("JOB_DEFINITION", ""),
            upload_expiry_seconds=_int(env, "UPLOAD_EXPIRY_SECONDS", 900, 60, 3600),
            result_url_expiry_seconds=_int(env, "RESULT_URL_EXPIRY_SECONDS", 300, 30, 3600),
        )
