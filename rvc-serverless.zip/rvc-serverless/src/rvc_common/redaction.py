"""Log redaction. Tokens must never reach CloudWatch, API responses or status.json."""
import logging
import re
import threading

_PATTERNS = [
    re.compile(r"hf_[A-Za-z0-9]{8,}"),                                   # Hugging Face tokens
    re.compile(r"(?i)(authorization\s*[:=]\s*)(?:bearer\s+)?\S+"),
    re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{8,}"),
    re.compile(r"(?i)(X-Amz-(?:Signature|Credential|Security-Token)=)[^&\s\"']+"),
    re.compile(r"(?i)(AWSAccessKeyId=)[^&\s\"']+"),
]
_secrets = set()
_lock = threading.Lock()
REDACTED = "[REDACTED]"


def register_secret(value) -> None:
    """Register an exact secret value so it is scrubbed even if it matches no pattern."""
    if isinstance(value, str) and len(value) >= 6:
        with _lock:
            _secrets.add(value)


def clear_secrets() -> None:
    with _lock:
        _secrets.clear()


def redact(text) -> str:
    text = str(text)
    with _lock:
        known = sorted(_secrets, key=len, reverse=True)
    for s in known:
        text = text.replace(s, REDACTED)
    for pat in _PATTERNS:
        if pat.groups >= 1:
            text = pat.sub(lambda m: m.group(1) + REDACTED, text)
        else:
            text = pat.sub(REDACTED, text)
    return text


class RedactingFormatter(logging.Formatter):
    """Redacts the fully rendered record, including exception tracebacks."""

    def format(self, record: logging.LogRecord) -> str:
        return redact(super().format(record))


def configure_logging(level=logging.INFO) -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(RedactingFormatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    root = logging.getLogger()
    for h in list(root.handlers):
        root.removeHandler(h)
    root.addHandler(handler)
    root.setLevel(level)
