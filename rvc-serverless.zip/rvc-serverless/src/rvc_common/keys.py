"""S3 key layout. Prefix-based so lifecycle rules can give each class its own retention."""

INPUT_PREFIX = "inputs/"      # uploaded audio          -> short retention, deleted by worker after the job
OUTPUT_PREFIX = "outputs/"    # converted audio         -> short retention
JOB_PREFIX = "jobs/"          # job.json / status.json  -> metadata retention


def input_key(job_id: str) -> str:
    return f"{INPUT_PREFIX}{job_id}/audio"


def output_key(job_id: str) -> str:
    return f"{OUTPUT_PREFIX}{job_id}/output.wav"


def job_key(job_id: str) -> str:
    return f"{JOB_PREFIX}{job_id}/job.json"


def status_key(job_id: str) -> str:
    return f"{JOB_PREFIX}{job_id}/status.json"
