"""Strict request validation: model source, options, job ids, input URLs.

Everything here is fail-closed. A model can only come from an allow-listed Hugging Face
repository; user-supplied URLs are never fetched verbatim -- they are parsed down to
(repo, revision, file) and the download URL is rebuilt from those validated parts.
"""
from __future__ import annotations

import ipaddress
import math
import re
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import quote, unquote, urlsplit

from .errors import RvcError
from .settings import Settings

_PART = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$")
_REVISION = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$")
_PINNED = re.compile(r"^[0-9a-f]{40}$")
_SEGMENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._ ()+\-]{0,127}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_JOB_ID = re.compile(r"^[0-9a-f]{32}$")
_CTRL = re.compile(r"[\x00-\x20\x7f]")

F0_METHODS = (
    "crepe", "crepe-tiny", "rmvpe", "fcpe",
    "hybrid[crepe+rmvpe]", "hybrid[crepe+fcpe]", "hybrid[rmvpe+fcpe]", "hybrid[crepe+rmvpe+fcpe]",
)


def _bad(code, message, status=400):
    return RvcError(code, message, http_status=status)


def is_pinned(revision: str) -> bool:
    return bool(_PINNED.match(revision or ""))


def validate_job_id(value) -> str:
    if not isinstance(value, str) or not _JOB_ID.match(value):
        raise _bad("INVALID_JOB_ID", "Job id is malformed.")
    return value


def validate_repo_id(value) -> str:
    if not isinstance(value, str) or value.count("/") != 1:
        raise _bad("INVALID_REPO_ID", "repo_id must look like 'owner/name'.")
    owner, name = value.split("/")
    if not _PART.match(owner) or not _PART.match(name):
        raise _bad("INVALID_REPO_ID", "repo_id contains invalid characters.")
    return value


def validate_revision(value) -> str:
    if not isinstance(value, str) or not _REVISION.match(value):
        raise _bad("INVALID_REVISION", "revision must be a branch, tag or commit SHA (no slashes).")
    return value


def validate_repo_file(value, suffix: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 256:
        raise _bad("INVALID_FILE", f"A {suffix} file path is required.")
    segments = value.split("/")
    if len(segments) > 6 or any(not _SEGMENT.match(s) or s in (".", "..") or ".." in s for s in segments):
        raise _bad("INVALID_FILE", "File path contains invalid characters or segments.")
    if not value.endswith(suffix):
        raise _bad("INVALID_FILE", f"File must end with {suffix}.")
    return value


def repo_allowed(repo_id: str, allowed: tuple) -> bool:
    owner, name = repo_id.lower().split("/")
    for entry in allowed:
        if entry == f"{owner}/{name}" or entry == f"{owner}/*":
            return True
    return False


def _reject_ip_literal(host: str):
    try:
        ipaddress.ip_address(host.strip("[]"))
    except ValueError:
        return
    raise _bad("URL_NOT_ALLOWED", "IP-address URLs are not allowed.")


def parse_hf_url(url, allowed_hosts: tuple):
    """'https://huggingface.co/o/r/resolve/<rev>/path/file.pth?x=1' -> (host, 'o/r', rev, 'path/file.pth')."""
    if not isinstance(url, str) or not url or len(url) > 2048 or _CTRL.search(url):
        raise _bad("URL_NOT_ALLOWED", "URL is missing or malformed.")
    try:
        parts = urlsplit(url)
        host = (parts.hostname or "").lower()
        port = parts.port
    except ValueError:
        raise _bad("URL_NOT_ALLOWED", "URL is malformed.")
    if parts.scheme != "https" or not host or parts.username is not None or parts.password is not None:
        raise _bad("URL_NOT_ALLOWED", "Only plain https URLs without credentials are allowed.")
    if port not in (None, 443):
        raise _bad("URL_NOT_ALLOWED", "Custom ports are not allowed.")
    _reject_ip_literal(host)
    if host not in allowed_hosts:
        raise _bad("URL_NOT_ALLOWED", "URL host is not allowed.")
    raw_segments = parts.path.split("/")
    if len(raw_segments) < 6 or raw_segments[0] != "" or raw_segments[3] not in ("resolve", "blob"):
        raise _bad("URL_NOT_ALLOWED", "Expected https://<host>/<owner>/<repo>/resolve/<revision>/<file>.")
    decoded = []
    for seg in raw_segments[1:]:
        d = unquote(seg)
        if "/" in d or "\\" in d or _CTRL.search(d):
            raise _bad("URL_NOT_ALLOWED", "URL path contains forbidden characters.")
        decoded.append(d)
    owner, repo, _kind, revision, *file_parts = decoded
    repo_id = validate_repo_id(f"{owner}/{repo}")
    validate_revision(revision)
    return host, repo_id, revision, "/".join(file_parts)


def resolve_url(host: str, repo_id: str, revision: str, file: str) -> str:
    """Rebuild the download URL from validated parts (never from raw user input)."""
    segs = [quote(p, safe="") for p in [*repo_id.split("/"), "resolve", revision, *file.split("/")]]
    return f"https://{host}/" + "/".join(segs)


@dataclass(frozen=True)
class ModelSpec:
    repo_id: str
    revision: str
    pth: str
    index: Optional[str] = None
    host: str = "huggingface.co"
    pth_sha256: Optional[str] = None
    index_sha256: Optional[str] = None

    @property
    def pinned(self) -> bool:
        return is_pinned(self.revision)

    def to_dict(self) -> dict:
        d = {"host": self.host, "repo_id": self.repo_id, "revision": self.revision, "pth": self.pth}
        if self.index:
            d["index"] = self.index
        if self.pth_sha256:
            d["pth_sha256"] = self.pth_sha256
        if self.index_sha256:
            d["index_sha256"] = self.index_sha256
        return d


_MODEL_KEYS = {"repo_id", "revision", "pth", "index", "url", "index_url", "host", "pth_sha256", "index_sha256"}


def parse_model(raw, settings: Settings) -> ModelSpec:
    if not isinstance(raw, dict):
        raise _bad("INVALID_MODEL", "model must be an object.")
    unknown = set(raw) - _MODEL_KEYS
    if unknown:
        raise _bad("INVALID_MODEL", "Unknown model field(s): " + ", ".join(sorted(map(str, unknown))[:5]))

    host = settings.allowed_download_hosts[0]
    repo_id = raw.get("repo_id")
    revision = raw.get("revision")
    pth = raw.get("pth")
    index = raw.get("index")

    if raw.get("host") is not None:
        h = str(raw["host"]).lower()
        if h not in settings.allowed_download_hosts:
            raise _bad("URL_NOT_ALLOWED", "Host is not allowed.")
        host = h

    if raw.get("url") is not None:
        u_host, u_repo, u_rev, u_file = parse_hf_url(raw["url"], settings.allowed_download_hosts)
        for given, parsed, what in ((repo_id, u_repo, "repo_id"), (revision, u_rev, "revision"), (pth, u_file, "pth")):
            if given is not None and given != parsed:
                raise _bad("INVALID_MODEL", f"{what} conflicts with url.")
        host, repo_id, revision, pth = u_host, u_repo, u_rev, u_file
        if raw.get("index_url") is not None:
            i_host, i_repo, i_rev, i_file = parse_hf_url(raw["index_url"], settings.allowed_download_hosts)
            if (i_host, i_repo, i_rev) != (host, repo_id, revision):
                raise _bad("INVALID_MODEL", "index_url must be in the same repo and revision as url.")
            if index is not None and index != i_file:
                raise _bad("INVALID_MODEL", "index conflicts with index_url.")
            index = i_file
    elif raw.get("index_url") is not None:
        raise _bad("INVALID_MODEL", "index_url requires url.")

    if repo_id is None:
        repo_id = settings.default_repo or None
    if repo_id is None:
        raise _bad("INVALID_MODEL", "repo_id (or url) is required.")
    repo_id = validate_repo_id(repo_id)
    if not repo_allowed(repo_id, settings.allowed_repos):          # fail closed when the list is empty
        raise _bad("MODEL_NOT_ALLOWED", "Repository is not in the allowed list.", 403)

    revision = "main" if revision is None else validate_revision(revision)
    if settings.require_pinned_revision and not is_pinned(revision):
        raise _bad("REVISION_NOT_PINNED", "revision must be a full 40-character commit SHA.")

    pth = validate_repo_file(pth, ".pth")
    if index is not None:
        index = validate_repo_file(index, ".index")

    sha = {}
    for key in ("pth_sha256", "index_sha256"):
        v = raw.get(key)
        if v is not None:
            if not isinstance(v, str) or not _SHA256.match(v.lower()):
                raise _bad("INVALID_MODEL", f"{key} must be 64 hex characters.")
            sha[key] = v.lower()
    return ModelSpec(repo_id=repo_id, revision=revision, pth=pth, index=index, host=host, **sha)


def _num(value, name, lo, hi, integer=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise _bad("INVALID_OPTIONS", f"{name} must be a number.")
    if isinstance(value, float) and not math.isfinite(value):
        raise _bad("INVALID_OPTIONS", f"{name} must be finite.")
    if integer and int(value) != value:
        raise _bad("INVALID_OPTIONS", f"{name} must be an integer.")
    if not (lo <= value <= hi):
        raise _bad("INVALID_OPTIONS", f"{name} must be between {lo} and {hi}.")
    return int(value) if integer else float(value)


def _flag(value, name):
    if not isinstance(value, bool):
        raise _bad("INVALID_OPTIONS", f"{name} must be true or false.")
    return value


# Ranges/choices mirror the click options seen in Applio's core.py (to be re-verified at the pinned tag).
_OPTION_RULES = {
    "pitch": lambda v: _num(v, "pitch", -24, 24, integer=True),
    "index_rate": lambda v: _num(v, "index_rate", 0, 1),
    "volume_envelope": lambda v: _num(v, "volume_envelope", 0, 1),
    "protect": lambda v: _num(v, "protect", 0, 0.5),
    "clean_strength": lambda v: _num(v, "clean_strength", 0, 1),
    "sid": lambda v: _num(v, "sid", 0, 255, integer=True),
    "split_audio": lambda v: _flag(v, "split_audio"),
    "clean_audio": lambda v: _flag(v, "clean_audio"),
    "f0_method": lambda v: v if v in F0_METHODS else (_ for _ in ()).throw(
        _bad("INVALID_OPTIONS", "f0_method is not supported.")),
}
DEFAULT_OPTIONS = {
    "pitch": 0, "index_rate": 0.3, "volume_envelope": 1.0, "protect": 0.33,
    "f0_method": "rmvpe", "split_audio": False, "clean_audio": False, "clean_strength": 0.7, "sid": 0,
}


def parse_options(raw) -> dict:
    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        raise _bad("INVALID_OPTIONS", "options must be an object.")
    unknown = set(raw) - set(_OPTION_RULES)
    if unknown:
        raise _bad("INVALID_OPTIONS", "Unsupported option(s): " + ", ".join(sorted(map(str, unknown))[:5]))
    out = dict(DEFAULT_OPTIONS)
    for key, value in raw.items():
        out[key] = _OPTION_RULES[key](value)
    return out


def validate_input_url(value, settings: Settings) -> str:
    if not settings.allowed_input_hosts:
        raise _bad("INPUT_URL_DISABLED", "input_url is disabled; upload the audio instead.")
    if not isinstance(value, str) or not value or len(value) > 2048 or _CTRL.search(value):
        raise _bad("URL_NOT_ALLOWED", "input_url is malformed.")
    try:
        parts = urlsplit(value)
        host, port = (parts.hostname or "").lower(), parts.port
    except ValueError:
        raise _bad("URL_NOT_ALLOWED", "input_url is malformed.")
    if parts.scheme != "https" or parts.username is not None or parts.password is not None or port not in (None, 443):
        raise _bad("URL_NOT_ALLOWED", "input_url must be a plain https URL on the default port.")
    _reject_ip_literal(host)
    if host not in settings.allowed_input_hosts:
        raise _bad("URL_NOT_ALLOWED", "input_url host is not allowed.")
    return value


@dataclass(frozen=True)
class JobRequest:
    model: ModelSpec
    options: dict = field(default_factory=dict)
    input_url: Optional[str] = None

    def to_dict(self) -> dict:
        d = {"model": self.model.to_dict(), "options": dict(self.options)}
        if self.input_url:
            d["input_url"] = self.input_url
        return d


def parse_job_request(raw, settings: Settings) -> JobRequest:
    if not isinstance(raw, dict):
        raise _bad("INVALID_REQUEST", "Request body must be a JSON object.")
    unknown = set(raw) - {"model", "options", "input_url"}
    if unknown:
        raise _bad("INVALID_REQUEST", "Unknown field(s): " + ", ".join(sorted(map(str, unknown))[:5]))
    model = parse_model(raw.get("model"), settings)
    options = parse_options(raw.get("options"))
    input_url = validate_input_url(raw["input_url"], settings) if raw.get("input_url") is not None else None
    return JobRequest(model=model, options=options, input_url=input_url)
