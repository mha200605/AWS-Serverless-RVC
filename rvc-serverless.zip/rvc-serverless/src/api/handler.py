"""API Lambda (API Gateway HTTP API, payload v2, IAM-authenticated).

  POST /jobs                 validate + store the job, return jobId and a presigned upload (or queue at once
                             when an allow-listed input_url is given)
  POST /jobs/{jobId}/start   after the upload: verify the object, submit the AWS Batch GPU job
  GET  /jobs/{jobId}         poll status; on success returns a short-lived presigned download URL

Responses never contain tokens, secret ARNs or raw Batch error text.
"""
from __future__ import annotations

import base64
import json
import logging
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

from rvc_common import keys
from rvc_common.errors import RvcError
from rvc_common.redaction import configure_logging
from rvc_common.settings import Settings
from rvc_common.validation import parse_job_request, validate_job_id

log = logging.getLogger("rvc.api")
MAX_BODY_BYTES = 16 * 1024
_QUEUED = {"SUBMITTED", "PENDING", "RUNNABLE", "STARTING"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _resp(status: int, body: dict) -> dict:
    return {"statusCode": status,
            "headers": {"Content-Type": "application/json", "Cache-Control": "no-store"},
            "body": json.dumps(body)}


def _err(exc: RvcError) -> dict:
    return _resp(exc.http_status, {"error": exc.to_dict()})


def _is_not_found(exc: Exception) -> bool:
    code = str(getattr(exc, "response", {}).get("Error", {}).get("Code", ""))
    return code in ("404", "NoSuchKey", "NotFound")


class Deps:
    def __init__(self, s3=None, batch=None, clock=time.time):
        self.s3, self.batch, self.clock = s3, batch, clock

    @classmethod
    def real(cls):
        import boto3
        return cls(boto3.client("s3"), boto3.client("batch"))


def _read_json(deps, bucket, key) -> Optional[dict]:
    try:
        return json.loads(deps.s3.get_object(Bucket=bucket, Key=key)["Body"].read())
    except Exception as exc:
        if _is_not_found(exc):
            return None
        raise


def _write_json(deps, bucket, key, doc) -> None:
    deps.s3.put_object(Bucket=bucket, Key=key, Body=json.dumps(doc).encode(), ContentType="application/json")


def _parse_body(event) -> Any:
    body = event.get("body") or ""
    if event.get("isBase64Encoded"):
        try:
            body = base64.b64decode(body).decode()
        except Exception:
            raise RvcError("INVALID_JSON", "Request body is not valid.")
    if len(body.encode()) > MAX_BODY_BYTES:
        raise RvcError("BODY_TOO_LARGE", "Request body is too large.", http_status=413)
    try:
        return json.loads(body) if body else {}
    except ValueError:
        raise RvcError("INVALID_JSON", "Request body must be valid JSON.")


def _submit(deps, settings, job_id, job):
    resp = deps.batch.submit_job(
        jobName=f"rvc-{job_id}", jobQueue=settings.job_queue, jobDefinition=settings.job_definition,
        containerOverrides={"environment": [{"name": "JOB_ID", "value": job_id}]})
    job["batchJobId"], job["state"], job["queuedAt"] = resp["jobId"], "QUEUED", _now()
    _write_json(deps, settings.bucket, keys.job_key(job_id), job)


def create_job(event, settings, deps) -> dict:
    request = parse_job_request(_parse_body(event), settings)
    job_id = uuid.uuid4().hex
    job = {"jobId": job_id, "createdAt": _now(), "request": request.to_dict(),
           "state": "QUEUED" if request.input_url else "AWAITING_UPLOAD"}
    _write_json(deps, settings.bucket, keys.job_key(job_id), job)
    if request.input_url:
        _submit(deps, settings, job_id, job)
        return _resp(202, {"jobId": job_id, "status": "QUEUED"})
    post = deps.s3.generate_presigned_post(
        Bucket=settings.bucket, Key=keys.input_key(job_id),
        Conditions=[["content-length-range", 1, settings.max_input_bytes]],
        ExpiresIn=settings.upload_expiry_seconds)
    return _resp(202, {"jobId": job_id, "status": "AWAITING_UPLOAD",
                       "upload": {"url": post["url"], "fields": post["fields"], "method": "POST (multipart/form-data)",
                                  "expiresInSeconds": settings.upload_expiry_seconds,
                                  "maxBytes": settings.max_input_bytes},
                       "next": f"POST /jobs/{job_id}/start after uploading"})


def start_job(job_id, settings, deps) -> dict:
    job = _read_json(deps, settings.bucket, keys.job_key(job_id))
    if job is None:
        raise RvcError("JOB_NOT_FOUND", "Job not found.", http_status=404)
    if job.get("batchJobId"):
        return _resp(200, {"jobId": job_id, "status": job.get("state", "QUEUED")})     # idempotent
    if job.get("state") != "AWAITING_UPLOAD":
        raise RvcError("INVALID_STATE", "Job cannot be started.", http_status=409)
    try:
        head = deps.s3.head_object(Bucket=settings.bucket, Key=keys.input_key(job_id))
    except Exception as exc:
        if _is_not_found(exc) or str(getattr(exc, "response", {}).get("Error", {}).get("Code", "")) == "403":
            raise RvcError("UPLOAD_MISSING", "No audio has been uploaded for this job yet.", http_status=409)
        raise
    if head["ContentLength"] > settings.max_input_bytes or head["ContentLength"] == 0:
        raise RvcError("UPLOAD_INVALID", "Uploaded audio has an invalid size.", http_status=409)
    _submit(deps, settings, job_id, job)
    return _resp(202, {"jobId": job_id, "status": "QUEUED"})


def _failure_from_batch(job: dict) -> dict:
    reason = f"{job.get('statusReason', '')} {job.get('container', {}).get('reason', '')}".lower()
    if "timeout" in reason or "timed out" in reason:
        return {"code": "JOB_TIMEOUT", "message": "The job exceeded its time limit."}
    if "outofmemory" in reason or "oom" in reason:
        return {"code": "OUT_OF_MEMORY", "message": "The worker ran out of memory."}
    return {"code": "WORKER_FAILED", "message": "The worker stopped before reporting a result."}


def get_job(job_id, settings, deps) -> dict:
    job = _read_json(deps, settings.bucket, keys.job_key(job_id))
    if job is None:
        raise RvcError("JOB_NOT_FOUND", "Job not found.", http_status=404)
    out: dict = {"jobId": job_id, "createdAt": job.get("createdAt"),
                 "model": {k: job["request"]["model"].get(k) for k in ("repo_id", "revision", "pth", "index")}}
    if not job.get("batchJobId"):
        out["status"] = job.get("state", "AWAITING_UPLOAD")
        return _resp(200, out)

    jobs = deps.batch.describe_jobs(jobs=[job["batchJobId"]]).get("jobs", [])
    batch_status = jobs[0]["status"] if jobs else "UNKNOWN"
    status_doc = _read_json(deps, settings.bucket, keys.status_key(job_id)) or {}

    if batch_status in _QUEUED or batch_status == "UNKNOWN":
        out["status"] = "QUEUED"
        queued = job.get("queuedAt")
        if queued:
            waited = deps.clock() - datetime.fromisoformat(queued).timestamp()
            out["queuedSeconds"] = int(waited)
            if batch_status == "RUNNABLE" and waited > 900:
                out["hint"] = "Waiting for GPU capacity for a long time; check the vCPU quota."
    elif batch_status == "RUNNING" and status_doc.get("state") not in ("SUCCEEDED", "FAILED"):
        out["status"], out["stage"] = "RUNNING", status_doc.get("stage")
    elif status_doc.get("state") == "SUCCEEDED":
        out["status"] = "SUCCEEDED"
        out["timings"] = status_doc.get("timings")
        url = deps.s3.generate_presigned_url(
            "get_object", Params={"Bucket": settings.bucket, "Key": keys.output_key(job_id),
                                  "ResponseContentDisposition": 'attachment; filename="converted.wav"',
                                  "ResponseContentType": "audio/wav"},
            ExpiresIn=settings.result_url_expiry_seconds)
        res = status_doc.get("result", {})
        out["result"] = {"url": url, "expiresInSeconds": settings.result_url_expiry_seconds,
                         "sizeBytes": res.get("sizeBytes"), "durationSeconds": res.get("durationSeconds")}
    elif status_doc.get("state") == "FAILED":
        out["status"], out["error"] = "FAILED", status_doc.get("error") or {"code": "WORKER_FAILED", "message": "Failed."}
    elif batch_status == "FAILED":
        out["status"], out["error"] = "FAILED", _failure_from_batch(jobs[0])
    else:                                    # Batch SUCCEEDED but worker wrote no result
        out["status"], out["error"] = "FAILED", {"code": "WORKER_NO_RESULT", "message": "The worker reported no result."}
    return _resp(200, out)


def lambda_handler(event, context=None, deps: Deps = None, settings: Settings = None):
    configure_logging()
    deps = deps or Deps.real()
    settings = settings or Settings.from_env()
    route = event.get("routeKey", "")
    try:
        if route == "POST /jobs":
            return create_job(event, settings, deps)
        if route not in ("POST /jobs/{jobId}/start", "GET /jobs/{jobId}"):
            return _resp(404, {"error": {"code": "NOT_FOUND", "message": "Unknown route."}})
        job_id = validate_job_id((event.get("pathParameters") or {}).get("jobId"))
        if route == "POST /jobs/{jobId}/start":
            return start_job(job_id, settings, deps)
        return get_job(job_id, settings, deps)
    except RvcError as exc:
        return _err(exc)
    except Exception:
        log.exception("unhandled error")
        return _resp(500, {"error": {"code": "INTERNAL_ERROR", "message": "Unexpected server error."}})
