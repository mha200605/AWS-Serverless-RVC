"""ffmpeg/ffprobe wrappers. All commands are argument lists (no shell) with a file-only protocol
whitelist, so a crafted playlist/concat file cannot make ffmpeg fetch network URLs (SSRF)."""
from __future__ import annotations

import json
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from rvc_common.errors import RvcError

# Container formats we accept (ffprobe `format_name` tokens). Playlists/concat/sdp etc. are rejected.
ALLOWED_FORMATS = {"wav", "mp3", "flac", "ogg", "aiff", "aac", "mov", "mp4", "m4a", "3gp", "matroska", "webm", "caf"}
_VOL = re.compile(r"max_volume:\s*(-?[0-9.]+|-inf)\s*dB")


@dataclass
class AudioInfo:
    duration: float
    sample_rate: int
    channels: int
    format_name: str


class AudioTools:
    def __init__(self, runner=subprocess.run, ffmpeg="ffmpeg", ffprobe="ffprobe"):
        self.run, self.ffmpeg, self.ffprobe = runner, ffmpeg, ffprobe

    def _run(self, cmd, timeout):
        try:
            return self.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
        except subprocess.TimeoutExpired:
            raise RvcError("INVALID_AUDIO", "Audio processing timed out.")
        except FileNotFoundError:
            raise RvcError("INTERNAL_ERROR", "Audio tooling is missing from the worker image.", http_status=500)

    def probe(self, path: Path) -> AudioInfo:
        proc = self._run([self.ffprobe, "-v", "error", "-protocol_whitelist", "file", "-print_format", "json",
                          "-show_format", "-show_streams", str(path)], 60)
        if proc.returncode != 0:
            raise RvcError("INVALID_AUDIO", "File is not readable audio.")
        try:
            data = json.loads(proc.stdout or "{}")
        except ValueError:
            raise RvcError("INVALID_AUDIO", "File is not readable audio.")
        fmt = data.get("format", {})
        names = set(str(fmt.get("format_name", "")).split(","))
        if not names & ALLOWED_FORMATS:
            raise RvcError("INVALID_AUDIO", "Audio container format is not supported.")
        streams = [s for s in data.get("streams", []) if s.get("codec_type") == "audio"]
        if not streams:
            raise RvcError("INVALID_AUDIO", "No audio stream found.")
        s = streams[0]
        try:
            duration = float(fmt.get("duration") or s.get("duration") or 0)
            return AudioInfo(duration, int(s.get("sample_rate") or 0), int(s.get("channels") or 0),
                             str(fmt.get("format_name", "")))
        except (TypeError, ValueError):
            raise RvcError("INVALID_AUDIO", "Audio metadata is invalid.")

    def to_wav(self, src: Path, dst: Path, max_seconds: int) -> None:
        proc = self._run([self.ffmpeg, "-nostdin", "-v", "error", "-protocol_whitelist", "file", "-i", str(src),
                          "-vn", "-map", "0:a:0", "-ac", "1", "-ar", "44100", "-t", str(max_seconds + 1),
                          "-c:a", "pcm_s16le", "-y", str(dst)], 300)
        if proc.returncode != 0 or not dst.exists() or dst.stat().st_size == 0:
            raise RvcError("INVALID_AUDIO", "Could not decode the input audio.")

    def max_volume_db(self, path: Path) -> Optional[float]:
        proc = self._run([self.ffmpeg, "-nostdin", "-hide_banner", "-nostats", "-protocol_whitelist", "file",
                          "-i", str(path), "-vn", "-af", "volumedetect", "-f", "null", "-"], 300)
        m = _VOL.search((proc.stderr or "") + (proc.stdout or ""))
        if not m:
            return None
        return float("-inf") if m.group(1) == "-inf" else float(m.group(1))
